# V3.8 七項缺口治理版

## 已實作
- 七項缺口機器可讀審核 `python audit_v38.py --out data/readiness.json`
- `integrations_v38.py` 提供帶時間戳、來源 URL、有效盤口線及重複報價檢查的 CSV 賠率匯入
- 陣容／傷停／xG 的 CSV 匯入與資料新鮮度及可信狀態標記
- 重用 V3.7 歷史時間切分校準、回測與 GitHub Actions 排程
- 預設 HOLD，不將使用者匯入的報價或陣容宣稱為已獨立驗證的即時資料

## 執行
`python -m unittest discover -s tests -v`
`python audit_v38.py --history sample_backtest.csv`
`python audit_v38.py --odds my_authorized_odds.csv --team-info my_authorized_team_news.csv`

## 尚未完成的外部條件
1. 可靠連線取得即時賽程及賽果，且核對資料時效
2. 取得合法持續使用的多公司賠率來源；本版只有匯入器，並非自動即時賠率 API
3. 取得可驗證的正選、傷停、xG 授權來源
4. 足夠真實歷史樣本及來源記錄，才能實際驗收概率校準
5. 帶當時報價的真實樣本外數據，才能驗收 ROI/CLV
6. 使用者的 GitHub/伺服器部署授權；提供設定不等於已部署
7. V2.8 原始碼／完整規則，才能做兼容差異驗證

本版係安全接入、審核同運作準備，**不是七項全部解決**。
