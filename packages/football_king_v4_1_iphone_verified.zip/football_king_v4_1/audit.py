"""Append-only JSONL audit; versioned and independently reproducible."""
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone

def append_record(path,record):
    if not isinstance(record,dict) or not record.get('case_id'):
        raise ValueError('case_id required')
    out=dict(record)
    out['recorded_utc']=datetime.now(timezone.utc).isoformat()
    encoded=json.dumps(out,sort_keys=True,ensure_ascii=False,allow_nan=False)
    out['sha256']=hashlib.sha256(encoded.encode()).hexdigest()
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf8') as f:
        f.write(json.dumps(out,ensure_ascii=False,sort_keys=True)+'\n')
    return out
