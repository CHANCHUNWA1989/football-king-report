"""One-shot keyless source refresh with bounded retries and fail-closed status."""
import argparse, json, os, time
from datetime import datetime,timezone
from pathlib import Path
from openfootball import fetch,LEAGUES
from fixture_gateway import current_season
from fixture_safety import compact_matches, capture_age_error

def refresh(season,league,out,retries=2,fetcher=fetch,sleeper=time.sleep):
    if retries<0 or retries>4: raise ValueError('INVALID_RETRIES')
    result=None; checked=datetime.now(timezone.utc); invalid_reason=None
    for attempt in range(retries+1):
        try: result=fetcher(season,league)
        except Exception as e: result={'status':'HOLD','reason':type(e).__name__,'matches':[]}
        if not isinstance(result,dict):
            result={'status':'HOLD','reason':'BAD_SOURCE_RESULT','matches':[]}
        rows,compact_error=compact_matches(result.get('matches'),checked)
        age_error=capture_age_error(result.get('captured_utc'),checked)
        invalid_reason=(age_error or compact_error or ('NO_MATCHES_IN_CURRENT_WINDOW' if not rows else None)) if result.get('status')=='READY_RESEARCH' else None
        if result.get('status')=='READY_RESEARCH' and not invalid_reason: break
        if attempt<retries: sleeper(min(2**attempt,8))
    ready=result.get('status')=='READY_RESEARCH' and not invalid_reason
    report={'status':'READY_RESEARCH' if ready else 'HOLD',
            'checked_utc':checked.isoformat(),'league':league,'season':season,
            'source_status':result.get('status'),'reason':invalid_reason or result.get('reason'),
            'matches':len(rows) if ready else 0,'source_url':result.get('source_url'),
            'sha256':result.get('sha256'),'production_recommendations':'DISABLED'}
    target=Path(out);target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix(target.suffix+'.tmp')
    temp.write_text(json.dumps({'report':report,'data':result},ensure_ascii=False,indent=2),encoding='utf8')
    os.replace(temp,target)
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--season');p.add_argument('--league',choices=list(LEAGUES),default='epl');p.add_argument('--out',default='data/latest.json');p.add_argument('--retries',type=int,default=2)
    a=p.parse_args();r=refresh(a.season or current_season(),a.league,a.out,a.retries);print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['status']=='READY_RESEARCH' else 2
if __name__=='__main__':raise SystemExit(main())
