"""Deterministic bounded load/stability tests. NO external site load generated.

Run: python stress_suite.py --out data/stress_report.json
Tests are local synthetic inputs; they do not validate prediction performance.
"""
import argparse
import json
import random
import tempfile
import time
import tracemalloc
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from daily_publish import collect_daily, publish

CLOCK=datetime(2026,10,8,10,0,tzinfo=timezone.utc)


def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',default='data/stress_report.json')
    args=parser.parse_args(argv)
    checks=[]
    tracemalloc.start()

    def record(name,start,success,**extra):
        checks.append({'scenario':name,'passed':bool(success),'seconds':round(time.perf_counter()-start,4),**extra})

    # High but bounded volume: 10,000 unique fixtures per requested league.
    start=time.perf_counter()
    many=[{'date':'2026-10-09','home':f'H{i}','away':f'A{i}', 'score_ft':None} for i in range(10000)]
    def large_source(*,season,league,clock):
        return {'status':'READY_RESEARCH','source':'STRESS_FIXTURE_SOURCE','matches':many}
    result=collect_daily(('epl','laliga','seriea','bundesliga','ligue1','championship'),now=CLOCK,getter=large_source)
    record('60k_source_fixture_input',start,
           result['status']=='READY_RESEARCH' and len(result['matches'])<=1200 and result['events_truncated'],
           source_rows=60000,stored_rows=len(result['matches']))

    start=time.perf_counter()
    too_many=many*3  # > 20k source rows should be rejected without processing.
    def oversized_source(*,season,league,clock):
        return {'status':'READY_RESEARCH','matches':too_many}
    result=collect_daily(('epl',),now=CLOCK,getter=oversized_source)
    record('30k_source_row_rejection',start,result['status']=='HOLD' and not result['matches'],source_rows=len(too_many))

    start=time.perf_counter()
    rng=random.Random(77)
    corrupt=[]
    for i in range(10000):
        corrupt.append(rng.choice([None,'A',42,{'date':'oops','home':i,'away':'X'},
                                    {'date':'2026-10-09','home':f'A{i}','away':'B','kickoff_utc':[]},
                                    {'date':'2026-10-09','home':f'H{i}','away':f'A{i}'}]))
    def noisy_source(*,season,league,clock):
        return {'status':'READY_RESEARCH','matches':corrupt}
    result=collect_daily(('epl',),now=CLOCK,getter=noisy_source)
    record('10k_random_malformed_input',start,result['production_recommendations']=='DISABLED',source_rows=10000,stored_rows=len(result['matches']))

    # No external network - deliberately execute concurrent file replacement with the same Pages directory.
    start=time.perf_counter()
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp); fixture={'status':'READY_RESEARCH',
            'matches':[{'date':'2026-10-09','home':'A','away':'B'}]}
        def work(i):
            r,_=publish(site=root/'site',report_path=root/f'r{i}.json',fixture_override=fixture,now=CLOCK)
            return r.get('production_recommendations')=='DISABLED'
        with ThreadPoolExecutor(max_workers=12) as pool:
            outputs=list(pool.map(work,range(100)))
        html=(root/'site'/'index.html').read_text(encoding='utf-8')
        doc=json.loads((root/'site'/'report.json').read_text(encoding='utf-8'))
        status=json.loads((root/'site'/'status.json').read_text(encoding='utf-8'))
        ok=all(outputs) and '足球王者' in html and doc['production_recommendations']=='DISABLED' and status['production_recommendations']=='DISABLED'
        record('100_concurrent_publish_runs',start,ok,parallel_workers=12,publish_runs=100)

    _,peak=tracemalloc.get_traced_memory()
    tracemalloc.stop()
    summary={'checked_utc':datetime.now(timezone.utc).isoformat(),
             'test_kind':'synthetic_local_stress_not_live_data',
             'passed':all(c['passed'] for c in checks),
             'passed_scenarios':sum(c['passed'] for c in checks),
             'scenario_count':len(checks),
             'peak_tracemalloc_megabytes':round(peak/1024/1024,2),
             'scenarios':checks,
             'limitations':['No outbound live source load generated','No actual GitHub Pages cloud test',
                            'No real betting odds or historical model verification','No guaranteed server uptime']}
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return 0 if summary['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
