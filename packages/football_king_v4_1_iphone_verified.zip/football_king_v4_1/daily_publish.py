"""One command for daily public fixture research and fail-closed iPhone Pages.
No bookmaker odds are invented, and never claims fixture source is independently verified.
"""
import argparse, json
from pathlib import Path
from datetime import datetime, timezone
from fixture_gateway import current_season, get_fixtures, select_window
from integrated import run
from mobile_site import build, atomic_write
from fixture_safety import compact_matches, capture_age_error, MAX_PUBLIC_MATCHES

DEFAULT_LEAGUES=('epl','championship','bundesliga','laliga','seriea','ligue1')


def collect_daily(leagues=DEFAULT_LEAGUES, season=None, now=None, getter=get_fixtures):
    now=now or datetime.now(timezone.utc)
    if now.tzinfo is None:raise ValueError('naive datetime')
    season=season or current_season(now)
    all_matches=[]; records=[]; seen=set(); total=0; any_truncated=False
    for league in leagues:
        try:
            r=getter(season=season,league=league,clock=lambda:now)
        except Exception as exc:  # public source failures must not suppress the daily HOLD page
            r={'status':'HOLD','reason':type(exc).__name__,'matches':[],'attempts':[]}
        rows=r.get('matches')
        if not isinstance(rows,list): rows=[]
        total+=len(rows)
        recent,trim_reason=compact_matches(rows,now=now)
        capture_error=capture_age_error(r.get('captured_utc'), now)
        source_invalid=trim_reason in ('SOURCE_EVENT_LIMIT_EXCEEDED','CONFLICTING_EVENT_IDENTITIES') or bool(capture_error)
        any_truncated=any_truncated or trim_reason in ('REPORT_EVENT_LIMIT_EXCEEDED','SOURCE_EVENT_LIMIT_EXCEEDED')
        for m in ([] if source_invalid else recent):
            if len(all_matches)>=MAX_PUBLIC_MATCHES:
                any_truncated=True
                break
            key=(league,m.get('date'),m.get('home'),m.get('away'))
            if key in seen:continue
            seen.add(key)
            all_matches.append({**m,'league':league,'source':r.get('source','UNKNOWN'),
                                'source_url':r.get('source_url'),
                                'captured_utc':r.get('captured_utc'),
                                'event_id':m.get('event_id') or None})
        fetched = r.get('status') == 'READY_RESEARCH' and bool(rows)
        usable = fetched and bool(recent) and not source_invalid
        records.append({'league':league,'source':r.get('source','NONE'),
                        'status':'READY_RESEARCH' if usable else 'HOLD',
                        'fetch_status':r.get('status','HOLD'),
                        'reason':(r.get('reason') if not fetched else
                                  capture_error or trim_reason if (capture_error or trim_reason) else (None if usable else 'NO_MATCHES_IN_CURRENT_WINDOW')),
                        'source_url':r.get('source_url'),
                        'captured_utc':r.get('captured_utc'),
                        'upstream_updated_utc':r.get('upstream_updated_utc'),
                        'dataset_matches':len(rows),'window_matches':len(recent),
                        'attempts':r.get('attempts',[])})
    all_matches.sort(key=lambda m:(m['date'],m.get('kickoff_utc') or '',m.get('league','')))
    good=sum(x['status']=='READY_RESEARCH' for x in records)
    fetched=sum(x['fetch_status']=='READY_RESEARCH' for x in records)
    return {'status':'READY_RESEARCH' if good else 'HOLD',
            'reason':None if good else ('NO_MATCHES_IN_CURRENT_WINDOW' if fetched else 'NO_SUCCESSFUL_PUBLIC_SOURCE'),
            'usable_sources':good,'fetched_sources':fetched,
            'source':'MULTI_KEYLESS','source_url':None, 'captured_utc':now.isoformat(),
            'upstream_updated_utc':None,'origin':'PUBLIC_KEYLESS_NETWORK',
            'verified_live':False, 'matches':all_matches,'source_records':records,
            'season':season,'dataset_total_matches':total,'events_truncated':any_truncated,
            'window':'past 2 days / next 21 days Hong Kong time',
            'limitations':['public datasets can be outdated','many leagues have unknown kickoff hour',
                           'no bookmaker odds; data retrieval does not verify match accuracy'],
            'production_recommendations':'DISABLED'}


def publish(site='site', report_path='data/daily_report.json', leagues=DEFAULT_LEAGUES,
            season=None, now=None, odds=None, team=None, history=None,
            fixture_override=None, getter=get_fixtures):
    now=now or datetime.now(timezone.utc)
    fixture=fixture_override if fixture_override is not None else collect_daily(leagues,season,now,getter)
    report=run(season=season,league='epl',odds=odds,team=team,history=history,now=now,fixture_override=fixture)
    report['fixture_source_records']=fixture.get('source_records',[])
    report['fixture_window']=fixture.get('window')
    report['fixture_dataset_total_matches']=fixture.get('dataset_total_matches')
    # Report always demonstrates missing authorization, and does not infer no matches
    # from a failed source.
    dst=Path(report_path);dst.parent.mkdir(parents=True,exist_ok=True)
    atomic_write(dst,json.dumps(report,ensure_ascii=False,indent=2))
    index=build(dst,site)
    return report,index


def main(argv=None):
    p=argparse.ArgumentParser(description='Football King daily iPhone report (research only)')
    p.add_argument('--site',default='site');p.add_argument('--report',default='data/daily_report.json')
    p.add_argument('--leagues',default=','.join(DEFAULT_LEAGUES))
    p.add_argument('--season');p.add_argument('--odds');p.add_argument('--team');p.add_argument('--history')
    args=p.parse_args(argv)
    leagues=[x.strip() for x in args.leagues.split(',') if x.strip()]
    if not leagues or len(leagues)>10: p.error('Please choose between 1 and 10 leagues')
    report,index=publish(site=args.site,report_path=args.report,leagues=leagues,
                        season=args.season,odds=args.odds,team=args.team,history=args.history)
    print(json.dumps({'status':report['status'],'sources':report['fixture_source_records'],
                      'window_matches':len(report['fixtures']['matches']),
                      'site':str(index),'production_recommendations':'DISABLED'},ensure_ascii=False))
    return 0 if report['status']=='RESEARCH_ONLY' else 2

if __name__=='__main__':raise SystemExit(main())
