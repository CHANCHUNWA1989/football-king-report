# 足球王者｜iPhone 研究報告安全修正版

本版本由 `football_king_release` 複製，原始候選版未被覆蓋。修正資料新鮮度誤判、每日報告錯誤升級狀態，以及 GitHub Pages 公開 `report.json` 可能洩露 CSV 匯入明細。

## 已修正（可測試）
1. 公開來源「成功下載」與「近期有賽事」分開記錄：`fetch_status` / `status`。如果全是窗口外的舊賽事，即使 HTTP 取得資料亦必須 HOLD，原因 `NO_MATCHES_IN_CURRENT_WINDOW`。
2. `integrated.run()` 不會把明確標為 `HOLD` 的賽事快照因其仍包含舊列而升級為 `RESEARCH_ONLY`。保留過去無 `status` 欄位的離線使用者資料相容。
3. `site/report.json` 僅公開白名單欄位，不輸出 `odds`、`team_info`、校準原始紀錄及賽事的任意額外欄位；本地 `data/daily_report.json` 保留診斷資料，切勿上載為網站靜態資產。
4. 網頁將「成功下載但無近期賽事」標成 HOLD 並提供來源摘要。
5. 正式投注推薦仍為 DISABLED，未經過模型真實回測及即時授權賠率驗證前不會啟用。

## 已知限制（未完成）
- 此工作環境對 OpenLigaDB、OpenFootball 進行真正 HTTP 下載時收到 `URLError`。本地測試採模擬資料；雲端需要獨立驗收。
- OpenFootball upstream 並不保證每日資料更新；抓取時間不是上游更新時間，沒有獨立覆核。
- 未有多博彩公司合法穩定即時賠率、正式正選／傷停／xG、自動模型實證、GitHub Pages 真正部署、V2.8 原始碼。
- GitHub Actions 每日排程不是逐分鐘 24 小時即時投注服務。

## 本地使用
```bash
python -m unittest discover -s tests -q
python daily_publish.py --site site --report data/daily_report.json
```
退出代碼 `2` = 數據來源無近期可研究內容，已產生 HOLD 網站；代碼 `0` = 有近期公開賽事供研究（仍不代表即時／投注推薦）。

## 用 iPhone 看雲端報告
需要把整個目錄推送到自己的 GitHub 儲存庫，Settings → Pages → Source 設 GitHub Actions，然後在 Actions 啟動 `Football King Daily iPhone Report`。成功部署後才會有實際網址。未部署前本地 `site/index.html` 僅作展示。

安全：GitHub Pages 可能對外公開。不要將帳戶密鑰、下注明細或私人 CSV 放入 `site` 資料夾。
