# 足球王者 V3.0 — 獨立研究版

此版本不覆蓋 V2.8，亦未連接即時賠率或自動排程。現有功能：1X2 Poisson 概率、輸入資料時效及風控檢查、CSV 歷史預測評估（Log Loss / 多分類 Brier / ROI）。未校準模型必定 HOLD，不會冒充正式推薦。

## 執行

```bash
python engine.py assess sample_snapshot.json
python engine.py backtest sample_backtest.csv
python -m unittest discover -s tests -v
```

## 後續生產化必要條件

1. 取得 V2.8 原始配置，做唯讀封存及輸出對照。
2. 取得合法授權賠率、正選、傷停及歷史 xG 數據，保留來源、UTC 時間戳、原始快照。
3. 實作 Elo、Dixon-Coles、雙變量 Poisson、無洩漏的 walk-forward stacking 和概率校準。這些尚未實作，不能宣稱已完成。
4. 為 1X2 以外玩法建立走盤、半贏、半輸完整結算規則。
5. 由外部排程器執行 T-180/T-60/T-20/T-10 檢查，紀錄每次執行結果。
6. Shadow Mode 累積足夠樣本，與 V2.8、市場基準比較並預先訂定驗收門檻。

## CSV 格式
`case_id,p_home,p_draw,p_away,outcome,odds,selection,placed`。placed 為 0 或 1。僅為等額單位投注示範，未計交易成本。
