"""Leakage-resistant chronological 1X2 calibration and out-of-sample evaluation."""
import csv, hashlib, json, math
from datetime import datetime, timezone
from pathlib import Path
LABELS=('home','draw','away')
def load(path):
    if Path(path).stat().st_size>20_000_000: raise ValueError('HISTORY_CSV_TOO_LARGE')
    with open(path,encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        required={'case_id','prediction_utc','kickoff_utc','p_home','p_draw','p_away','outcome'}
        if not required.issubset(set(reader.fieldnames or [])): raise ValueError('MISSING_PREDICTION_COLUMNS')
        rows=list(reader)
    if not rows: raise ValueError('EMPTY_DATASET')
    seen=set(); result=[]
    for r in rows:
        if not r['case_id'] or r['case_id'] in seen: raise ValueError('DUPLICATE_CASE')
        seen.add(r['case_id'])
        pred=datetime.fromisoformat(r['prediction_utc'].replace('Z','+00:00'))
        ko=datetime.fromisoformat(r['kickoff_utc'].replace('Z','+00:00'))
        if pred.tzinfo is None or ko.tzinfo is None or pred>=ko: raise ValueError('BAD_CHRONOLOGY')
        p=[float(r['p_'+x]) for x in LABELS]
        if any(not math.isfinite(x) or x<0 or x>1 for x in p) or abs(sum(p)-1)>1e-6: raise ValueError('BAD_PROBABILITIES')
        if r['outcome'] not in LABELS: raise ValueError('BAD_OUTCOME')
        result.append((ko.astimezone(timezone.utc),pred.astimezone(timezone.utc),p,LABELS.index(r['outcome'])))
    result.sort(key=lambda x:x[0]);return result

def transform(p,temp):
    v=[max(x,1e-12)**(1/temp) for x in p]; z=sum(v);return [x/z for x in v]
def score(rows,temp):
    loss=brier=0.
    for _,_,p,y in rows:
        q=transform(p,temp);loss-=math.log(max(q[y],1e-15));brier+=sum((x-int(i==y))**2 for i,x in enumerate(q))
    return {'n':len(rows),'log_loss':loss/len(rows),'brier':brier/len(rows)}
def evaluate(path,train_fraction=.6,validation_fraction=.2,min_train=30,min_validation=10,min_test=10):
    rows=load(path); n=len(rows)
    if not (0<train_fraction<1 and 0<validation_fraction<1 and train_fraction+validation_fraction<1): raise ValueError('BAD_SPLIT')
    a=int(n*train_fraction); b=int(n*(train_fraction+validation_fraction))
    train,valid,test=rows[:a],rows[a:b],rows[b:]
    if min(len(train),len(valid),len(test))<1 or len(train)<min_train or len(valid)<min_validation or len(test)<min_test:
        return {'status':'HOLD','reason':'INSUFFICIENT_CHRONOLOGICAL_SAMPLE','n':n,'split':[len(train),len(valid),len(test)]}
    # Outcome availability: training matches must finish before first validation prediction,
    # and validation matches must finish before first test prediction. Use conservative 3h match duration.
    from datetime import timedelta
    if train[-1][0]+timedelta(hours=3)>=min(x[1] for x in valid) or valid[-1][0]+timedelta(hours=3)>=min(x[1] for x in test):
        return {'status':'HOLD','reason':'POTENTIAL_LABEL_LEAKAGE','n':n}
    # Fit temperature only on training; validation selects between calibrated and raw.
    temperatures=[.65,.75,.85,1.,1.15,1.3,1.5,1.8,2.2]
    candidate=min(temperatures,key=lambda t:score(train,t)['log_loss'])
    chosen=candidate if score(valid,candidate)['log_loss']<score(valid,1.)['log_loss'] else 1.
    return {'status':'RESEARCH_ONLY','n':n,'split':[len(train),len(valid),len(test)],
            'temperature':chosen,'train':score(train,chosen),'validation':score(valid,chosen),
            'test':score(test,chosen),'test_raw':score(test,1.),
            'dataset_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'warnings':['not a verified model certificate','no ROI or CLV without contemporaneous odds','single holdout is not proof of future performance']}
