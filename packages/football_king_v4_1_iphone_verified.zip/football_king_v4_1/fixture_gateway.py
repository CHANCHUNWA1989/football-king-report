"""Keyless, documented public football fixture access; research use only.

OpenFootball: CC0 upstream. OpenLigaDB: public API for German leagues.
A successful HTTP response proves retrieval, NOT independent match verification.
"""
from __future__ import annotations
import hashlib
import json
from datetime import date, datetime, timedelta, timezone
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo
from openfootball import fetch as openfootball_fetch

OLDB_ROOT = 'https://api.openligadb.de/getmatchdata'
GERMAN_LEAGUES = {'bundesliga': 'bl1', 'bundesliga2': 'bl2', 'bundesliga3': 'bl3'}
HK = ZoneInfo('Asia/Hong_Kong')


def current_season(now=None):
    """YYYY-YY season based on Hong Kong local time (July-June)."""
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None: raise ValueError('naive datetime not allowed')
    y = now.astimezone(HK).year
    m = now.astimezone(HK).month
    start = y if m >= 7 else y - 1
    return f'{start}-{(start+1)%100:02d}'


def _utc_now(clock):
    now = clock() if clock else datetime.now(timezone.utc)
    if now.tzinfo is None: raise ValueError('UTC time must be timezone-aware')
    return now.astimezone(timezone.utc)


def fetch_openligadb(season, league='bundesliga', opener=urlopen, clock=None):
    if league not in GERMAN_LEAGUES: raise ValueError('Unsupported OpenLigaDB league')
    if not (isinstance(season, str) and len(season)==7 and season[:4].isdigit() and season[4]=='-' and season[5:].isdigit() and int(season[5:])==(int(season[:4])+1)%100):
        raise ValueError('Invalid season')
    url=f'{OLDB_ROOT}/{GERMAN_LEAGUES[league]}/{season[:4]}'
    try:
        req=Request(url, headers={'User-Agent':'FootballKingResearch/4.0 (public documented API)', 'Accept':'application/json'})
        with opener(req,timeout=12) as r:
            body=r.read(8_000_001)
        if len(body)>8_000_000: raise ValueError('OVERSIZE')
        src=json.loads(body)
        if not isinstance(src,list): raise ValueError('BAD_SCHEMA')
        rows=[]; seen=set()
        for m in src:
            if not isinstance(m,dict):continue
            mid=m.get('matchID')
            try:
                if not (isinstance(mid,int) and mid>0):continue
                home=m['team1']['teamName'].strip(); away=m['team2']['teamName'].strip()
                if not home or not away or home==away or mid in seen:continue
                stamp=m.get('matchDateTimeUTC')
                if not isinstance(stamp,str) or not stamp: continue
                dt=datetime.fromisoformat(stamp.replace('Z','+00:00'))
                if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc) # API field says UTC
                dt=dt.astimezone(timezone.utc)
                date_str=dt.astimezone(HK).date().isoformat()
                ft=None
                results=m.get('matchResults')
                if isinstance(results,list) and m.get('matchIsFinished') is True:
                    for rr in results:
                        if not isinstance(rr,dict) or rr.get('resultTypeID')!=2:continue
                        a,b=rr.get('pointsTeam1'),rr.get('pointsTeam2')
                        if type(a)==int and type(b)==int and min(a,b)>=0:ft=[a,b]
                seen.add(mid)
                rows.append({'date':date_str,'home':home,'away':away,'score_ft':ft,
                             'status':'FINISHED' if ft is not None else ('FINISHED_UNSCORED' if m.get('matchIsFinished') else 'SCHEDULED'),
                             'kickoff_utc':dt.isoformat(),'event_id':f'openligadb:{mid}', 'source':'OpenLigaDB'})
            except (TypeError,ValueError,KeyError,AttributeError,OverflowError):continue
        captured=_utc_now(clock).isoformat()
        return {'status':'READY_RESEARCH' if rows else 'HOLD', 'reason':None if rows else 'NO_VALID_MATCHES',
                'source':'OpenLigaDB', 'source_url':url,'captured_utc':captured,
                'upstream_updated_utc':None, 'sha256':hashlib.sha256(body).hexdigest(),
                'season':season,'league':league,'matches':rows,
                'limitations':['crowdsourced: not independently verified','no bookmaker odds, lineups or xG',
                               'HTTP retrieval is not proof of source freshness'],
                'production_recommendations':'DISABLED'}
    except (HTTPError,URLError,TimeoutError,OSError,ValueError,TypeError,json.JSONDecodeError) as exc:
        return {'status':'HOLD','reason':type(exc).__name__, 'source':'OpenLigaDB', 'source_url':url,
                'matches':[],'production_recommendations':'DISABLED'}


def get_fixtures(season=None,league='epl',clock=None,openfootball_fn=None,openligadb_fn=None):
    """Try public German API first for Bundesliga; fallback to OpenFootball.
    Fail closed without turning old cached/synthetic matches into 'live'.
    """
    now = _utc_now(clock)
    season = season or current_season(now)
    attempts=[]
    sources=[]
    stale_success=False
    if league in GERMAN_LEAGUES:
        sources.append(('OpenLigaDB',openligadb_fn or fetch_openligadb))
    if league in ('epl','championship','bundesliga','laliga','seriea','ligue1'):
        sources.append(('OpenFootball',openfootball_fn or openfootball_fetch))
    if not sources:raise ValueError('UNSUPPORTED_LEAGUE')
    for name,fn in sources:
        try:
            r=fn(season,league,clock=lambda:now)
            attempts.append({'source':name,'status':r.get('status'),'reason':r.get('reason')})
            if r.get('status')=='READY_RESEARCH' and r.get('matches'):
                from fixture_safety import compact_matches, capture_age_error
                usable,invalid=compact_matches(r['matches'],now)
                freshness_error=capture_age_error(r.get('captured_utc'),now)
                if not usable or invalid in ('SOURCE_EVENT_LIMIT_EXCEEDED','CONFLICTING_EVENT_IDENTITIES') or freshness_error:
                    attempts[-1]['status']='HOLD'
                    attempts[-1]['reason']=freshness_error or invalid or 'NO_MATCHES_IN_CURRENT_WINDOW'
                    stale_success=True
                    continue
                result=dict(r)
                result['attempts']=attempts
                result['origin']='PUBLIC_KEYLESS_NETWORK'
                result['verified_live']=False
                result['upstream_updated_utc']=result.get('upstream_updated_utc')
                return result
        except (ValueError,TypeError,OSError) as exc:
            attempts.append({'source':name,'status':'HOLD','reason':type(exc).__name__})
    return {'status':'HOLD','reason':('NO_USABLE_RECENT_MATCHES' if stale_success else 'ALL_PUBLIC_SOURCES_FAILED'),'source':'keyless-gateway',
            'attempts':attempts,'matches':[], 'captured_utc':now.isoformat(),
            'origin':'PUBLIC_KEYLESS_NETWORK','verified_live':False,
            'production_recommendations':'DISABLED'}


def select_window(matches,now=None,past_days=2,future_days=21):
    now=now or datetime.now(timezone.utc)
    today=now.astimezone(HK).date()
    lo=today-timedelta(days=past_days); hi=today+timedelta(days=future_days)
    rows=[]
    for m in matches:
        if not isinstance(m,dict):continue
        try:d=date.fromisoformat(m['date'])
        except (ValueError,TypeError,KeyError):continue
        if lo<=d<=hi:rows.append(m)
    return sorted(rows,key=lambda m:(m['date'],m.get('kickoff_utc') or '',m.get('home','')))
