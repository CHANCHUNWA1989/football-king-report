# 足球王者｜iPhone 每日中文報告部署指引

## 使用目的
這是一個可部署、免足球數據 API Key 的足球賽程**研究**系統，不是已經正式上線的投注推薦服務。

### 已經可運作的部分
- `python daily_publish.py --site site --report data/daily_report.json`：逐一獲取公開賽程，產生手機 HTML、JSON 與來源診斷。
- 不設 Key：使用 OpenFootball CC0 JSON；德甲優先使用 OpenLigaDB 公開 API，失敗會降級。
- 足球資料源未連通、更新延遲、沒有盤口及模型實證，仍可生成不捏造推薦的 HOLD 頁面。
- 自動根據香港日期換算賽季、將賽程限制在過去 2 天及未來 21 天。
- GitHub Actions 每天 **09:17 香港時間**嘗試生成並發布 GitHub Pages。執行可能延遲或失敗；不是即時監測。

### iPhone 透過 GitHub 雲端部署
1. 需要自己的 GitHub 帳號／倉庫。**目前 ZIP 並未替你部署**。在 GitHub 建立倉庫，把本資料夾的所有檔案及隱藏 `.github/workflows/mobile-report.yml` 一起提交到預設分支。只上載 ZIP 檔不會自動解壓執行；建議用電腦、GitHub Desktop 或已連接的 GitHub 整合將資料完整提交。手機 Safari 從 GitHub 網頁管理可能會較繁瑣。
2. GitHub 儲存庫 → Settings → Pages → Build and deployment → Source = **GitHub Actions**。
3. GitHub Actions → **Football King Daily iPhone Report** → **Run workflow**，先手動執行一次。
4. 執行完成，到 Settings → Pages 取得網址，用 iPhone Safari 開啟，按分享 → 加入主畫面。
5. 查看 `status.json` 或 GitHub Actions 執行結果，確定該次採集真的成功；即使工作流程成功，資料來源亦可能 HOLD。

**私隱提醒：** GitHub Pages 的靜態報告一般可被公開存取。不要把私人帳戶資料、API Key、個人投注明細加入 GitHub Pages。

### 試運行指令
```bash
python -m unittest discover -s tests -q
python daily_publish.py --site site --report data/daily_report.json
```
返回代碼 `0` = 有公開資料供研究；代碼 `2` = 數據來源失敗，已輸出 HOLD 報告；其他代碼 = 程式故障。

單一聯賽診斷（減少免費來源負載）：
```bash
python daily_publish.py --leagues bundesliga --site site --report data/daily_report.json
```

### 仍然缺少、不能隱藏的限制
1. 免金鑰公開賽程不等同即時比分或真實陣容，OpenFootball 上游更新未必及時。
2. 未接通正式授權的多博彩公司即時盤口、xG、正選、傷停資料；CSV 匯入功能不等於即時來源。
3. 尚無足夠真實歷史預測快照及賽前盤口來驗證模型與 ROI/CLV；不能證明具有穩定盈利優勢。
4. GitHub Actions/Pages 未經你的帳戶授權，不能替你啟用；不提供 24 小時持續監控 SLA。
5. 缺 V2.8 完整原始程式，因此無法證明舊版兼容。

### 授權／來源依據
- OpenFootball：<https://github.com/openfootball/football.json> (public domain/CC0)
- OpenLigaDB 文件：<https://github.com/OpenLigaDB/OpenLigaDB-Samples> (公開 API 文檔；遵守合理速率)
- GitHub Pages：<https://docs.github.com/en/pages>

**請不要把單元測試通過率，當作足球推薦命中率。**
