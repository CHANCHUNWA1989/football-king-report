"""Authorized football-data.org v4 collector. No scraping or access bypass."""
import argparse, csv, hashlib, json, os, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

BASE='https://api.football-data.org/v4/matches'

def collect(date_from,date_to,token=None,opener=urlopen,clock=None):
    from datetime import date
    start,end=date.fromisoformat(date_from),date.fromisoformat(date_to)
    if start>end or (end-start).days>7: raise ValueError('date range must be <=7 days')
    token=token or os.environ.get('FOOTBALL_DATA_API_KEY')
    if not token: return {'status':'HOLD','reason':'API_KEY_REQUIRED','matches':[]}
    url=f'{BASE}?dateFrom={start.isoformat()}&dateTo={end.isoformat()}'
    req=Request(url,headers={'X-Auth-Token':token,'User-Agent':'FootballKingResearch/3.4','Accept':'application/json'})
    try:
        with opener(req,timeout=20) as response:
            body=response.read(5_000_001)
            if len(body)>5_000_000: raise ValueError('response too large')
        raw=json.loads(body)
        if not isinstance(raw.get('matches'),list): raise ValueError('invalid API schema')
        matches=[]
        for m in raw['matches']:
            if not isinstance(m,dict): continue
            if not all(k in m for k in ('id','utcDate','homeTeam','awayTeam','status')): continue
            matches.append({'event_id':str(m['id']),'kickoff_utc':m['utcDate'],
                'home':m['homeTeam'].get('name'),'away':m['awayTeam'].get('name'),
                'status':m['status'],'source':'football-data.org v4'})
        stamp=(clock or (lambda:datetime.now(timezone.utc)))().isoformat()
        return {'status':'READY','captured_utc':stamp,'source_url':url,'source':'football-data.org v4',
                'sha256':hashlib.sha256(body).hexdigest(),'matches':matches,
                'limitations':['no live odds','no verified xG','no lineup verification']}
    except (HTTPError,URLError,TimeoutError,OSError,ValueError,json.JSONDecodeError) as e:
        return {'status':'HOLD','reason':type(e).__name__,'matches':[]}

def import_local_csv(path):
    """User-supplied CSV only. Do not silently scrape restricted third-party data."""
    with open(path,newline='',encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    if not rows: raise ValueError('empty csv')
    return {'status':'IMPORTED_UNVERIFIED','row_count':len(rows),'columns':list(rows[0]),
            'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'warning':'check provenance, licensing, time availability, and leakage before training'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--from-date');p.add_argument('--to-date');p.add_argument('--csv');p.add_argument('--out');a=p.parse_args()
    result=import_local_csv(a.csv) if a.csv else collect(a.from_date,a.to_date)
    output=json.dumps(result,ensure_ascii=False,indent=2)
    if a.out: Path(a.out).write_text(output,encoding='utf-8')
    print(output)
