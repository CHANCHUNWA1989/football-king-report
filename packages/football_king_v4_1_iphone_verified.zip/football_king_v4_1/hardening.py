"""Fail-closed market checks; no network calls."""
from datetime import datetime, timezone
from math import isfinite

LABELS=('home','draw','away')
def utc(s):
    if not isinstance(s,str): raise ValueError('invalid timestamp')
    d=datetime.fromisoformat(s.replace('Z','+00:00'))
    if d.tzinfo is None: raise ValueError('timezone required')
    return d.astimezone(timezone.utc)

def check_quote(q, now, event_id, max_age=20):
    if q.get('event_id')!=event_id: raise ValueError('wrong event')
    if not isinstance(q.get('source'),str) or not q['source'].strip(): raise ValueError('missing source')
    age=(now-utc(q['captured_utc'])).total_seconds()/60
    if not 0<=age<=max_age: raise ValueError('stale/future quote')
    odds={k:float(q[k]) for k in LABELS}
    if any(not isfinite(v) or not 1<v<100 for v in odds.values()): raise ValueError('invalid odds')
    return odds

def probability(p):
    if isinstance(p,bool) or not isinstance(p,(float,int)) or not isfinite(p) or not 0<=p<=1:
        raise ValueError('invalid probability')
    return float(p)
