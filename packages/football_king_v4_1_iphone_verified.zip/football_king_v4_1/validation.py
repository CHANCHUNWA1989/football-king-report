"""Validate time-ordered out-of-sample 1X2 predictions. Not a trust authority."""
import csv, json, math, hashlib
from pathlib import Path
from datetime import datetime

LABELS=('home','draw','away')
def report(path, minimum=100):
    with open(path, encoding='utf-8-sig', newline='') as f: rows=list(csv.DictReader(f))
    seen=set(); previous=None; ll=bs=0.; bins={i:[0.,0.,0] for i in range(10)}
    for r in rows:
        key=r['case_id']
        if not key or key in seen: raise ValueError('duplicate/empty case_id')
        seen.add(key)
        ts=datetime.fromisoformat(r['prediction_utc'].replace('Z','+00:00'))
        ko=datetime.fromisoformat(r['kickoff_utc'].replace('Z','+00:00'))
        if not ts.tzinfo or not ko.tzinfo or ts>=ko: raise ValueError('invalid chronology')
        if previous and ko<previous: raise ValueError('rows must be kickoff ordered')
        previous=ko
        probs=[float(r['p_'+k]) for k in LABELS]
        if not all(math.isfinite(v) and 0<=v<=1 for v in probs) or abs(sum(probs)-1)>1e-6: raise ValueError('invalid probabilities')
        if r['outcome'] not in LABELS: raise ValueError('invalid outcome')
        y=LABELS.index(r['outcome'])
        ll-=math.log(max(probs[y],1e-15));bs+=sum((p-int(i==y))**2 for i,p in enumerate(probs))
        for i,p in enumerate(probs):
            b=min(9,int(p*10)); bins[b][0]+=1;bins[b][1]+=p;bins[b][2]+=int(i==y)
    n=len(rows)
    if not n: raise ValueError('empty dataset')
    calibration=[{'bin':i,'n':int(c),'mean_p':sp/c,'frequency':sy/c} for i,(c,sp,sy) in bins.items() if c]
    digest=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return {'n':n,'minimum_met':n>=minimum,'log_loss':ll/n,'brier':bs/n,'calibration':calibration,'dataset_sha256':digest,'status':'RESEARCH_ONLY'}

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('csv');p.add_argument('--minimum',type=int,default=100);a=p.parse_args()
    print(json.dumps(report(a.csv,a.minimum),indent=2))
