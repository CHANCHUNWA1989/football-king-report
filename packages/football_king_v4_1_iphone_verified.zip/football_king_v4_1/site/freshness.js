(() => {
  const banner = document.getElementById('research-banner');
  if (!banner) return;
  const timestamp = Date.parse(banner.dataset.checked || '');
  if (!Number.isFinite(timestamp) || Date.now() - timestamp > 36*60*60*1000 || timestamp - Date.now() > 5*60*1000) {
    banner.textContent = 'HOLD：此網頁報告已過期或更新時間異常，請查閱最新運行紀錄';
    banner.style.color = '#b45309';
  }
})();
