# 足球王者｜壓力測試與 iPhone 雲端交付版

> 實際狀態：本地程式及模擬壓力測試通過。**未接通真正即時博彩公司報價，亦未在使用者 GitHub 進行部署驗收**。系統必須維持研究用途、正式推薦停用。 

## 執行

```bash
python -m unittest discover -s tests -q
python stress_suite.py --out data/stress_report.json
python daily_publish.py --site site --report data/daily_report.json
```

`daily_publish.py` 的退出代碼：`0` 代表有當期公開賽程供研究；`2` 代表來源失效或無合格近期數據，已產生 HOLD 頁面；其他代碼才代表本地執行錯誤。

## 專項修復

1. **不可信資料驗證**：日期、時區、開賽時間、主客隊及比分標準化；不允許異常數字或不同型別資料觸發賽事排序錯誤。
2. **資源限制**：單來源每個聯賽最多 20,000 原始行；只使用 750 筆近期賽事，整份報告最多 1,200 筆；限制 CSV/研究報告大小。容量上限達到時，標記截斷或 HOLD。
3. **德甲來源備援**：當 OpenLigaDB 返回的均為非當期賽事，繼續嘗試 OpenFootball；全部失效則 HOLD。
4. **盤口標準化**：`2.50` 與 `2.5` 視為相同盤口，再比較公司報價；仍缺自動合法即時盤口來源。
5. **日報穩定性**：多個來源分別隔離失敗；CSV 缺失可產生 HOLD；JSON/HTML 使用原子寫入及 POSIX 排他檔案鎖，降低並行半寫入風險。
6. **公共網頁資料收斂**：公開輸出白名單、報告數量上限、公開來源網址白名單，避免外部私人 token URL 出現在 `site/report.json`。
7. **手機舊頁面警告**：Safari 載入舊於 36 小時或異常未來時間嘅報告，`freshness.js` 顯示 HOLD；前端顯示不會修改後端或重新抓取來源。
8. **持續驗證**：原始 79 個測試，加 17 個回歸／資源測試，另有可重跑的合成壓力情境；GitHub Actions 每日工作流程新增壓測與診斷 artifact。

## 壓力測試規模及限制

`stress_suite.py` 使用合成資料，測試 60,000 筆原始賽程量、30,000 超限拒絕、10,000 筆混亂資料及 100 次（12 worker）並行寫入。此測試**沒有向公開網站發起負載壓測**；不保證真實網絡可用、GitHub 云端 uptime、模型命中率或獲利能力。

## iPhone 部署

1. 在 GitHub 建立儲存庫並提交整個資料夾，包括 `.github/workflows/mobile-report.yml`。
2. 到 Settings → Pages → Build and deployment，將來源設定成 GitHub Actions。
3. 到 Actions 手動執行 `Football King Daily iPhone Report`，確認測試、壓測及資料採集執行紀錄。
4. 在 Pages 頁面取得真正網址，使用 iPhone Safari 開啟並加入主畫面。
5. 檢查網站 `status.json` 嘅 `checked_utc`、`sources_http_success` 及 `window_matches`，不能把「部署成功」當成「即時數據已驗證」。

> 注意：GitHub 連接、儲存庫上傳及 Pages 啟用，需要用戶實際授權其 GitHub 帳戶。單憑聊天中講「授權」不會自動提供 OAuth 權限。若未完成連接，我哋只可以交付可部署程式包。

## 未解決的重要外部限制

- 完整、合法、多博彩公司即時盤口及亞洲盤：仍欠授權資料連接，CSV 匯入不等於即時抓取。
- 正選、傷停、xG：仍欠可信自動資料供應商及時間驗證。
- 真實歷史概率校準和樣本外 ROI/CLV：需要實際預測時間快照和當時市場報價。
- iPhone GitHub Pages 真正上線與持續監控：未部署，需帳戶連接。
- 舊版 V2.8 完整兼容：未有原始程式，未驗證。

所有狀況仍維持 `production_recommendations = DISABLED`。
