# 足球王者｜2026-10-08 系統修復及 iPhone 雲端候選版

## 今次已經真正實作嘅改善

- `fixture_safety.capture_age_error()`：當來源宣稱有 `captured_utc` 時，超過36小時、未來超過5分鐘、或者格式錯誤會 HOLD。抓取時間 ≠ 上游更新時間，仍非賽事獨立驗證。
- `fixture_safety.compact_matches()`：同一 `event_id` 卻有不同日期或隊伍時，隔離衝突記錄，避免錯配；對有衝突嘅單一來源唔宣稱可用。
- `fixture_gateway.py`：德甲優先來源有衝突、超量或時間異常時嘗試備援公開來源。
- `daily_publish.py`、`integrated.py`：避免過期抓取時間同衝突資料令來源被誤判為可研究。
- `mobile_site.py`：除了前端 JavaScript 提醒，後端產生頁面時亦會檢查報告是否超過36小時或超前5分鐘，異常即 HOLD。
- `sync_v37.py`：修正原有同步會接受壞資料而顯示 READY_RESEARCH 的問題，亦不再強制輸入固定球季。
- `.github/workflows/`：兩項次要工作流程移除寫死嘅 2026-27 球季；主手機工作流程加上發布前嘅 `healthcheck.py` 檢查。
- `healthcheck.py`：檢查 HTML、JSON、狀態一致性及正式推薦停用旗標；exit 0 研究可用、2 安全 HOLD、1 工件損壞／不一致。

## 已實測

- `python -m unittest discover -s tests -q` → 117 tests OK，包含新增21項回歸／自檢測試（上一版96項）。
- `python stress_suite.py --out data/stress_report.json` → 4／4 組本地**合成**壓力情境通過。並非真實網站壓測。
- `python daily_publish.py --site site --report data/daily_report.json` → 命令正常生成網站，因外網 URLError 返回 exit 2／HOLD。**這不是最新足球賽事成功採集。**
- `python healthcheck.py --site site` → exit 2／HOLD，工件完整且阻止未經核實的推薦。

## iPhone / GitHub Pages 上線步驟

1. 先在 Safari 能正常登入原有 GitHub 帳戶；目前使用者畫面顯示 `Email domain could not be verified`，需透過 GitHub 帳戶支援解決；不要提供密碼給任何人。
2. 將此 ZIP 解壓，整個專案**包括隱藏 `.github` 資料夾**提交至你的 GitHub repo。iPhone 上批量上傳整個資料夾不方便；可使用電腦或支援 Git 的雲端編輯環境。
3. GitHub Repo `Settings → Pages → Build and deployment → Source: GitHub Actions`。
4. `Actions → Football King Daily iPhone Report → Run workflow`，成功之後再查看運行日誌和 `status.json`。
5. 使用 Pages 所提供網址於 iPhone Safari 開啟；即使部署成功，如果來源仍無法連線，頁面理應明確顯示 HOLD。

### 必須明確區分

**已完成**：程式修復、本地自動測試、手機靜態網頁產生與自檢、可部署 YAML。

**尚未完成**：使用者 GitHub 帳戶授權/Pages 上線；真實即時多博彩公司合法報價串流；正選/傷停/xG 自動接入；真實歷史樣本外模型驗證；V2.8 原始碼兼容驗證。

任何單元測試、壓力測試通過，都不是投注命中率或盈利保證。正式推薦始終 `DISABLED`。
