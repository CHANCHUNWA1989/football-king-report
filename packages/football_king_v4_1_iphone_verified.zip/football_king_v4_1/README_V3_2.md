# 足球王者 V3.2 — 安全修復版

本版本係 V3.1 獨立複本，未改動 V2.8/V3.1。

## 已修復
- 嚴格檢查報價賽事 ID、時間戳、來源及有效數字（包括拒絕 NaN/Infinity）
- 多個同場報價未有明確選擇規則時 HOLD，避免任意取第一個
- 保守概率不可大於模型點估計；無效模型識別 HOLD
- Poisson 輸入及回測概率拒絕非有限數值
- 新增八個回歸測試；共 24 項通過

## 使用
在資料夾執行 `python -m unittest discover -s tests -v`。
以 `python monitor.py sample_pipeline.json --now 2026-10-08T12:00:00Z --log audit.jsonl` 執行一次離線示範檢查。

## 未完成 / 不可宣稱
- 沒有即時賠率、傷停、xG、正選 API
- 沒有持續執行服務或真實樣本外訓練、概率校準
- V2.8 原始碼尚未取得，不能證實兼容
- `calibrated`、`oos_evaluated` 仍由輸入宣告，未有可信簽章及外部驗證；即使出現 PASS_CANDIDATE 亦**不是正式推薦**
- 目前只處理 1X2；亞洲盤與大小球結算未實作
