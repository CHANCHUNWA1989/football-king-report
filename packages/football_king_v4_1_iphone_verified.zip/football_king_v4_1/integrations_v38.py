"""Fail-closed ingestion of permissioned/public data and seven-point readiness audit."""
import csv, json, math, hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path

def utc(s):
    t=datetime.fromisoformat(s.replace('Z','+00:00'))
    if t.tzinfo is None: raise ValueError('NAIVE_TIMESTAMP')
    return t.astimezone(timezone.utc)

def import_odds(path, now=None, max_age_minutes=15):
    """CSV columns: event_id,bookmaker,market,line,selection,decimal_odds,observed_utc,source_url."""
    required={'event_id','bookmaker','market','line','selection','decimal_odds','observed_utc','source_url'}
    now=now or datetime.now(timezone.utc)
    if Path(path).stat().st_size>10_000_000: raise ValueError('CSV_TOO_LARGE')
    with open(path,encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f)
        if not required.issubset(r.fieldnames or []): raise ValueError('MISSING_ODDS_COLUMNS')
        rows=list(r)
        if len(rows)>20000: raise ValueError('CSV_TOO_MANY_ROWS')
    accepted=[]; rejected=[]; seen=set()
    for i,row in enumerate(rows,2):
        try:
            if not all(row[k].strip() for k in ('event_id','bookmaker','market','selection','source_url')): raise ValueError('MISSING_IDENTITY')
            if not row['source_url'].startswith('https://'): raise ValueError('SOURCE_NOT_HTTPS')
            if row['market'] not in ('1x2','asian_handicap','over_under'): raise ValueError('UNSUPPORTED_MARKET')
            if row['market']=='1x2':
                if row['selection'] not in ('home','draw','away') or row['line'].strip(): raise ValueError('INVALID_1X2')
            else:
                if row['selection'] not in (('home','away') if row['market']=='asian_handicap' else ('over','under')): raise ValueError('INVALID_SELECTION')
                line=float(row['line']);
                if not math.isfinite(line) or abs(line*4-round(line*4))>1e-8: raise ValueError('INVALID_LINE')
                if row['market']=='over_under' and line<0: raise ValueError('INVALID_LINE')
                row['line']=f'{line:g}' if line else '0'
            price=float(row['decimal_odds'])
            if not math.isfinite(price) or price<=1 or price>1000: raise ValueError('INVALID_ODDS')
            stamp=utc(row['observed_utc']); age=(now-stamp).total_seconds()/60
            if age< -2 or age>max_age_minutes: raise ValueError('STALE_OR_FUTURE')
            key=(row['event_id'],row['bookmaker'],row['market'],row['line'],row['selection'])
            if key in seen: raise ValueError('DUPLICATE_QUOTE')
            seen.add(key); accepted.append({**row,'decimal_odds':price,'observed_utc':stamp.isoformat()})
        except (ValueError,KeyError,TypeError) as e: rejected.append({'row':i,'reason':str(e)})
    return {'status':'RESEARCH_ONLY' if accepted else 'HOLD','accepted':accepted,'rejected':rejected,'source_file_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'production_recommendations':'DISABLED'}

def import_team_info(path,now=None,max_age_hours=48):
    required={'event_id','team','kind','status','observed_utc','source_url'}
    now=now or datetime.now(timezone.utc)
    if Path(path).stat().st_size>10_000_000: raise ValueError('CSV_TOO_LARGE')
    with open(path,encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f)
        if not required.issubset(r.fieldnames or []): raise ValueError('MISSING_TEAM_INFO_COLUMNS')
        rows=list(r)
        if len(rows)>20000: raise ValueError('CSV_TOO_MANY_ROWS')
    accepted=[];rejected=[]
    for i,row in enumerate(rows,2):
        try:
            if not all(row[k].strip() for k in ('event_id','team','kind','status','source_url')): raise ValueError('MISSING_FIELD')
            if not row['source_url'].startswith('https://'): raise ValueError('INVALID_SOURCE')
            if row['kind'] not in ('lineup','injury','xg'): raise ValueError('INVALID_KIND')
            if row['status'] not in ('confirmed','reported','unverified'): raise ValueError('INVALID_STATUS')
            age=(now-utc(row['observed_utc'])).total_seconds()/3600
            if age < -1/30 or age>max_age_hours: raise ValueError('STALE_OR_FUTURE')
            accepted.append(row)
        except (ValueError,KeyError,TypeError) as e: rejected.append({'row':i,'reason':str(e)})
    return {'status':'RESEARCH_ONLY' if accepted else 'HOLD','accepted':accepted,'rejected':rejected,'production_recommendations':'DISABLED'}

def audit(base,odds=None,team_info=None,legacy=None,history=None):
    base=Path(base)
    checks={
      '01_fixtures':{'status':'HOLD','reason':'NO_VERIFIED_LIVE_SYNC'},
      '02_bookmaker_odds':{'status':'HOLD','reason':'NO_VERIFIED_CURRENT_ODDS'},
      '03_lineup_injury_xg':{'status':'HOLD','reason':'NO_VERIFIED_TEAM_DATA'},
      '04_calibration':{'status':'HOLD','reason':'NO_REAL_CALIBRATION_EVIDENCE'},
      '05_backtest':{'status':'HOLD','reason':'NO_REAL_OUT_OF_SAMPLE_EVIDENCE'},
      '06_monitoring':{'status':'HOLD','reason':'NOT_DEPLOYED'},
      '07_v28_compatibility':{'status':'HOLD','reason':'ORIGINAL_V28_MISSING'}}
    sync=base/'data/latest.json'
    if sync.exists():
        try:
            d=json.loads(sync.read_text()); report=d.get('report',{})
            if report.get('status')=='READY_RESEARCH':
                stamp=utc(report['checked_utc']);age=(datetime.now(timezone.utc)-stamp).total_seconds()/3600
                if 0<=age<=24: checks['01_fixtures']={'status':'RESEARCH_ONLY','reason':'RECENT_SYNC_NOT_INDEPENDENTLY_VERIFIED'}
        except (ValueError,KeyError,TypeError): pass
    if odds:
        result=import_odds(odds)
        if result['accepted']: checks['02_bookmaker_odds']={'status':'RESEARCH_ONLY','accepted':len(result['accepted']),'reason':'IMPORTED_NOT_LIVE_VERIFIED'}
    if team_info:
        result=import_team_info(team_info)
        if result['accepted']: checks['03_lineup_injury_xg']={'status':'RESEARCH_ONLY','accepted':len(result['accepted']),'reason':'IMPORTED_NOT_CROSS_VERIFIED'}
    if history:
        from research_v37 import evaluate
        try:
            result=evaluate(history)
            if result['status']=='RESEARCH_ONLY':
                checks['04_calibration']={'status':'RESEARCH_ONLY','reason':'HOLDOUT_EVALUATED_NOT_CERTIFIED','n':result['n']}
                checks['05_backtest']={'status':'RESEARCH_ONLY','reason':'NO_VERIFIED_ODDS_ROI_CLV','n':result['n']}
        except (ValueError,TypeError,ZeroDivisionError) as e: checks['05_backtest']['reason']=type(e).__name__
    if legacy and Path(legacy).exists(): checks['07_v28_compatibility']={'status':'REVIEW_REQUIRED','reason':'LEGACY_SOURCE_PRESENT_NEEDS_DIFF'}
    return {'status':'HOLD','checked_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'production_recommendations':'DISABLED'}
