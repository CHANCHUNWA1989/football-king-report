# 足球王者 V3.4 — 合規數據採集模組

舊版 V3.3 完全保留。本版新增 `collector.py`，使用 football-data.org 官方 v4 API 取得賽程（須使用者自行取得授權 API Key），保存來源、UTC 時間、SHA256，出錯則 HOLD。**不會爬取被禁止的網站，不會繞過登入、付費或 CAPTCHA。**

```bash
export FOOTBALL_DATA_API_KEY='your_authorized_key'
python collector.py --from-date 2026-10-08 --to-date 2026-10-09 --out fixtures.json
python collector.py --csv your_licensed_history.csv
python -m unittest discover -s tests -v
```

API 呼叫僅按需執行，沒有啟用背景排程。API 賽程不包括即時賠率、xG、官方正選。歷史數據 CSV 僅導入用戶合法提供的檔案，不自動訓練。V3.3 原有研究模型及 HOLD 風控保持不變；未校準前不可正式推薦。所有網路 API 使用前須確認最新授權條款及速率限制。
