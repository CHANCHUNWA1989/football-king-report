"""Asian handicap / total settlement, including quarter lines; unit stakes."""
from math import isfinite

def _half_result(diff):
    return 1 if diff>1e-9 else -1 if diff< -1e-9 else 0

def _split(line):
    if not isinstance(line,(int,float)) or not isfinite(line) or abs(line*4-round(line*4))>1e-8: raise ValueError('line must be a quarter goal')
    quarter=round(line*4)
    if quarter%2==0:return [line]
    return [(quarter-1)/4,(quarter+1)/4]

def settle(market, selection, line, home, away, odds, stake=1.):
    if not all(isinstance(x,(int,float)) and isfinite(x) for x in (home,away,odds,stake)) or min(home,away)<0 or int(home)!=home or int(away)!=away or odds<=1 or stake<=0:raise ValueError('invalid scores, odds or stake')
    lines=_split(line)
    if market=='AH' and selection in ('home','away'):
        diff=home-away if selection=='home' else away-home
    elif market=='OU' and selection in ('over','under'):
        diff=home+away if selection=='over' else -(home+away)
    else: raise ValueError('unsupported market or selection')
    result=[]
    for x in lines:
        if market=='AH': adjusted=diff+x
        elif selection=='under': adjusted=x-(home+away)
        else: adjusted=(home+away)-x
        outcome=_half_result(adjusted)
        result.append((odds-1 if outcome>0 else -1 if outcome<0 else 0)*stake/len(lines))
    return round(sum(result),10)
