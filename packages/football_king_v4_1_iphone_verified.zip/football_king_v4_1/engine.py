"""Football King V3.0: offline, auditable research engine. No live feed bundled."""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from math import exp, factorial, log, isfinite
from pathlib import Path
import csv, json, argparse

@dataclass
class Snapshot:
    case_id: str
    kickoff_utc: str
    captured_utc: str
    home: str
    away: str
    market: str
    selection: str
    odds: float
    model_home_goals: float
    model_away_goals: float
    lineup_confirmed: bool
    source: str

def poisson(k, lam): return exp(-lam) * lam**k / factorial(k)

def probabilities(h, a, max_goals=12):
    if not isfinite(h) or not isfinite(a) or not (0<h<=8 and 0<a<=8): raise ValueError('expected goals must be finite and within (0,8]')
    home = draw = away = 0.0
    for i in range(max_goals+1):
        for j in range(max_goals+1):
            p=poisson(i,h)*poisson(j,a)
            if i>j: home+=p
            elif i==j: draw+=p
            else: away+=p
    s=home+draw+away
    return {'home':home/s,'draw':draw/s,'away':away/s}

def assess(s: Snapshot, now=None, max_age_minutes=20):
    now=now or datetime.now(timezone.utc)
    issues=[]
    try:
        captured=datetime.fromisoformat(s.captured_utc.replace('Z','+00:00'))
        kickoff=datetime.fromisoformat(s.kickoff_utc.replace('Z','+00:00'))
        if captured.tzinfo is None or kickoff.tzinfo is None: raise ValueError()
        age=(now-captured).total_seconds()/60
        if age<0 or age>max_age_minutes: issues.append('STALE_OR_FUTURE_SNAPSHOT')
        if now>=kickoff: issues.append('KICKOFF_PASSED')
    except ValueError: issues.append('INVALID_TIMESTAMP')
    if not s.source.strip(): issues.append('MISSING_SOURCE')
    if not s.lineup_confirmed: issues.append('LINEUP_UNCONFIRMED')
    if s.market!='1X2' or s.selection not in ('home','draw','away'): issues.append('UNSUPPORTED_MARKET')
    if not 1<s.odds<100: issues.append('INVALID_ODDS')
    if s.odds<1.8: issues.append('BELOW_POLICY_ODDS')
    try: p=probabilities(s.model_home_goals,s.model_away_goals).get(s.selection)
    except (ValueError,OverflowError): p=None; issues.append('INVALID_MODEL_INPUT')
    ev=p*s.odds-1 if p is not None and s.odds>1 else None
    # This model is deliberately uncalibrated. Positive EV alone cannot authorize a bet.
    issues.append('UNCALIBRATED_MODEL')
    return {'case_id':s.case_id,'status':'HOLD' if issues else 'PASS','issues':issues,'model_probability':p,'illustrative_ev':ev,'model_version':'3.0.0-research'}

def evaluate_csv(path):
    """CSV columns: case_id, p_home, p_draw, p_away, outcome, odds, selection, placed (0/1)."""
    with open(path,encoding='utf-8-sig',newline='') as file:
        rows=list(csv.DictReader(file))
    if not rows: raise ValueError('Empty CSV')
    ll=bs=profit=stake=0.0
    for r in rows:
        probs=[float(r['p_home']),float(r['p_draw']),float(r['p_away'])]
        if any(not isfinite(v) for v in probs) or min(probs)<0 or max(probs)>1 or abs(sum(probs)-1)>1e-5: raise ValueError('Invalid probabilities')
        outcome=r['outcome']; labels=['home','draw','away']
        if outcome not in labels: raise ValueError('Invalid outcome')
        y=[int(k==outcome) for k in labels]
        ll-=log(max(probs[labels.index(outcome)],1e-15))
        bs+=sum((p-t)**2 for p,t in zip(probs,y))
        if int(r.get('placed','0')):
            odds=float(r['odds']); selection=r['selection']
            if not isfinite(odds) or odds<=1 or selection not in labels: raise ValueError('Invalid bet')
            profit+=odds-1 if selection==outcome else -1
            stake+=1
    return {'n':len(rows),'log_loss':ll/len(rows),'multiclass_brier':bs/len(rows),'bets':int(stake),'unit_profit':profit,'roi':profit/stake if stake else None}

def main():
    parser=argparse.ArgumentParser()
    sub=parser.add_subparsers(dest='command',required=True)
    a=sub.add_parser('assess');a.add_argument('snapshot_json')
    b=sub.add_parser('backtest');b.add_argument('csv')
    args=parser.parse_args()
    result=assess(Snapshot(**json.loads(Path(args.snapshot_json).read_text(encoding='utf8')))) if args.command=='assess' else evaluate_csv(args.csv)
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
