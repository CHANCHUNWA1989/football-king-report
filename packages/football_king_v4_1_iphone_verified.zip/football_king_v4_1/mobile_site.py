"""Static, phone-first zh-HK report. Data is public research; no betting picks."""
import argparse, json, html, os, tempfile, contextlib
from urllib.parse import urlsplit
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from fixture_gateway import select_window
from fixture_safety import compact_matches, MAX_PUBLIC_MATCHES, MAX_PUBLIC_SOURCE_RECORDS

HK=ZoneInfo('Asia/Hong_Kong')

CLIENT_FRESHNESS_JS = """(() => {
  const banner = document.getElementById('research-banner');
  if (!banner) return;
  const timestamp = Date.parse(banner.dataset.checked || '');
  if (!Number.isFinite(timestamp) || Date.now() - timestamp > 36*60*60*1000 || timestamp - Date.now() > 5*60*1000) {
    banner.textContent = 'HOLD：此網頁報告已過期或更新時間異常，請查閱最新運行紀錄';
    banner.style.color = '#b45309';
  }
})();
"""

def e(value):
    value=str(value if value is not None else '—')
    return html.escape(value[:500] + ('…' if len(value)>500 else ''), quote=True)


def public_source_url(value):
    """Only publish known public data URLs. Never expose tokens in custom CSV/override URLs."""
    if not isinstance(value,str) or len(value)>300: return None
    try:
        p=urlsplit(value)
        if p.scheme!='https' or p.username or p.password or p.query or p.fragment: return None
        if p.hostname=='raw.githubusercontent.com' and p.path.startswith('/openfootball/football.json/'):
            return value
        if p.hostname=='api.openligadb.de' and p.path.startswith('/getmatchdata/'):
            return value
    except ValueError: pass
    return None


def atomic_write(path,content):
    """Replace a complete report file, never expose half-written JSON/HTML."""
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=f'.{path.name}.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            out.write(content)
            out.flush()
            os.fsync(out.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


@contextlib.contextmanager
def publish_lock(destination):
    """Cooperate with other publishing processes on POSIX cloud runners."""
    import fcntl
    destination=Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    lockfile=destination.parent/f'.{destination.name}.publish.lock'
    with open(lockfile,'a+b') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        try: yield
        finally: fcntl.flock(f,fcntl.LOCK_UN)

def public_subset(report):
    """Allowlist public Pages payload; never publish imported private quotes or team CSV rows."""
    fixtures = report.get('fixtures') or {}
    safe_matches = []
    for m in (fixtures.get('matches') or [])[:MAX_PUBLIC_MATCHES]:
        if not isinstance(m, dict):
            continue
        match={k:m.get(k) for k in (
            'date','home','away','score_ft','status','kickoff_utc',
            'league','source','captured_utc','event_id') if k in m}
        match['source_url']=public_source_url(m.get('source_url'))
        safe_matches.append(match)
    safe_fixtures = {k: fixtures.get(k) for k in (
        'status','reason','source','source_url','captured_utc','upstream_updated_utc',
        'season','dataset_total_matches','window','limitations','production_recommendations'
    ) if k in fixtures}
    safe_fixtures['matches'] = safe_matches
    safe_fixtures['source_url']=public_source_url(fixtures.get('source_url'))
    # Only simple status fields, no raw CSV, odds or third-party free text payloads.
    safe_checks = {}
    for name, check in (report.get('checks') or {}).items():
        if isinstance(check, dict):
            safe_checks[name] = {k:v for k,v in check.items()
                                 if k in ('status','reason','count','records','quotes','bookmakers','comparable_groups')
                                 and isinstance(v,(str,int,float,type(None)))}
    safe_sources=[]
    for rec in (report.get('fixture_source_records') or [])[:MAX_PUBLIC_SOURCE_RECORDS]:
        if isinstance(rec,dict):
            entry={k:rec.get(k) for k in (
                'league','source','status','fetch_status','reason',
                'captured_utc','upstream_updated_utc','window_matches','dataset_matches') if k in rec}
            entry['source_url']=public_source_url(rec.get('source_url'))
            safe_sources.append(entry)
    return {
        'version':report.get('version'), 'checked_utc':report.get('checked_utc'),
        'status':report.get('status','HOLD'),
        'production_recommendations':'DISABLED',
        'checks':safe_checks, 'fixtures':safe_fixtures,
        'fixture_source_records':safe_sources,
        'fixture_window':report.get('fixture_window'),
        'warnings':['Research-only; public fixture sources can be stale.',
                    'No bookmaker live feed or validated model profitability.']
    }


def build(report_path, output_dir, wall_clock=None):
    if Path(report_path).stat().st_size>16_000_000: raise ValueError('REPORT_JSON_TOO_LARGE')
    report=json.loads(Path(report_path).read_text(encoding='utf-8'))
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    status=report.get('status','HOLD')
    checks=report.get('checks') or {}
    fixture=report.get('fixtures') or {}
    raw=fixture.get('matches') or []
    actual_now=wall_clock or datetime.now(timezone.utc)
    if actual_now.tzinfo is None:raise ValueError('AWARE_WALL_CLOCK_REQUIRED')
    timestamp_error=False
    try:
        now=datetime.fromisoformat(str(report['checked_utc']).replace('Z','+00:00'))
        if now.tzinfo is None:raise ValueError('NAIVE_REPORT_TIMESTAMP')
        delta=(actual_now.astimezone(timezone.utc)-now.astimezone(timezone.utc)).total_seconds()
        if delta>36*3600 or delta < -5*60:
            timestamp_error=True
    except (ValueError,KeyError,TypeError,OverflowError):
        now=actual_now
        timestamp_error=True
    window,window_limit=compact_matches(raw,now=now,max_output=MAX_PUBLIC_MATCHES)
    if timestamp_error:
        status='HOLD'  # Server-side, even if Safari JavaScript is disabled.
    if status=='RESEARCH_ONLY' and not window:
        status='HOLD'  # Do not show green success if a supplied report contains zero usable upcoming matches.
    # Ensure a fixture collection containing unrelated older games never overwhelms the phone.
    rows=[]
    for m in window[:80]:
        if not isinstance(m,dict):continue
        date=e(m.get('date','未知日期'))
        ko=m.get('kickoff_utc')
        hour='開賽時間未核實'
        if ko:
            try:
                t=datetime.fromisoformat(str(ko).replace('Z','+00:00'))
                if t.tzinfo is not None:hour=t.astimezone(HK).strftime('%H:%M HKT')
            except (TypeError,ValueError):pass
        home=e(m.get('home',m.get('home_team','未知主隊')))
        away=e(m.get('away',m.get('away_team','未知客隊')))
        league=e(m.get('league',''))
        source=e(m.get('source',fixture.get('source','未知來源')))
        score=m.get('score_ft')
        result=('　'+e(score[0])+'–'+e(score[1])) if isinstance(score,list) and len(score)==2 else ''
        rows.append(f'<article class="match"><div class="small">{date}　{e(hour)}　·　{league}</div><div class="teams">{home} — {away}{result}</div><div class="small">來源：{source} · 未獨立驗證</div></article>')
    src_records=report.get('fixture_source_records') or fixture.get('source_records') or []
    src_items=[]
    for x in src_records:
        if not isinstance(x,dict):continue
        s='已取得公開資料' if x.get('status')=='READY_RESEARCH' else '採集失敗 / HOLD'
        src_items.append(f'<li><b>{e(x.get("league"))}</b>｜{e(x.get("source"))}｜{s}｜本期賽事 {e(x.get("window_matches",0))}｜{e(x.get("reason",""))}</li>')
    check_rows=''.join(f'<tr><th>{e(k)}</th><td>{e(v.get("status","HOLD"))}</td><td>{e(v.get("reason",""))}</td></tr>' for k,v in checks.items() if isinstance(v,dict))
    hk_now=now.astimezone(HK).strftime('%Y-%m-%d %H:%M HKT')
    success=sum(x.get('status')=='READY_RESEARCH' for x in src_records)
    fetched=sum(x.get('fetch_status',x.get('status'))=='READY_RESEARCH' for x in src_records)
    banner=('HOLD：報告產生時間過期或不可信' if timestamp_error
            else '有近期公開賽程供研究（未獨立核實）' if status=='RESEARCH_ONLY'
            else 'HOLD：資料下載成功但近期賽事不足' if fetched
            else 'HOLD：未成功取得公開賽程')
    notes='來源嘅抓取時間唔等於上游資料更新時間。公開資料可能延遲；缺少比賽唔代表當日無賽事。'
    content=f'''<!doctype html><html lang="zh-HK"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><meta name="color-scheme" content="light dark"/><meta http-equiv="Cache-Control" content="no-cache"/><title>足球王者｜iPhone 足球研究報告</title><style>
:root{{font-family:-apple-system,BlinkMacSystemFont,"Noto Sans TC",Arial,sans-serif;line-height:1.55}}
body{{max-width:760px;margin:0 auto;padding:20px 15px 60px;background:Canvas;color:CanvasText}}
h1{{font-size:1.45rem;margin:0 0 7px}}h2{{font-size:1.07rem;margin:25px 0 9px}}
section,.match{{border:1px solid #8f8f8f55;border-radius:14px;padding:14px;margin:10px 0}}
.hero{{background:rgba(110,110,110,.075)}}.status{{font-weight:750}}.small,small{{font-size:.77rem;opacity:.76}}
.teams{{font-size:1rem;font-weight:650;margin:5px 0}}.pills{{display:flex;flex-wrap:wrap;gap:8px}}
.pill{{border:1px solid #8887;border-radius:30px;padding:5px 10px;font-size:.78rem}}
table{{border-collapse:collapse;width:100%;font-size:.75rem}}td,th{{padding:8px 5px;text-align:left;border-bottom:1px solid #8885;vertical-align:top;overflow-wrap:anywhere}}th{{font-weight:550}}
.scroll{{overflow-x:auto}}ul{{padding-left:22px}}li{{margin:8px 0}}a{{color:inherit}}footer{{margin-top:35px}}
</style></head><body>
<h1>⚽ 足球王者</h1><div class="small">iPhone 每日繁體中文足球研究報告</div>
<section class="hero"><div class="status" id="research-banner" data-checked="{e(now.isoformat())}">{e(banner)}</div><p>更新時間：<b>{e(hk_now)}</b></p>
<div class="pills"><span class="pill">近期可用來源：{success}/{len(src_records)}</span><span class="pill">近期賽事：{len(window)}</span><span class="pill">正式投注推薦：停用</span></div>
<p class="small">{e(notes)}</p></section>
<h2>近期賽程與賽果</h2><p class="small">香港時間：過去2日及未來21日，顯示最多80場。並非實時比賽列表。</p>
{''.join(rows) if rows else '<section>暫無可核實資料；保持 HOLD。請檢查來源狀態。</section>'}
<h2>公開來源運行狀態</h2><section><ul>{''.join(src_items) if src_items else '<li>沒有來源運行紀錄</li>'}</ul></section>
<h2>七大缺口狀態</h2><div class="scroll"><table><thead><tr><th>檢查項目</th><th>結果</th><th>原因</th></tr></thead><tbody>{check_rows}</tbody></table></div>
<footer class="small"><p>本網站不提供自動投注或盈利保證。缺少即時多博彩公司賠率、已確認正選及真實回測證明時，只作研究。</p><p><a href="report.json">完整原始報告（JSON）</a> · <a href="status.json">最近更新狀態（JSON）</a></p></footer>
<script src="freshness.js" defer></script></body></html>'''
    safe=public_subset(report)
    safe['status']=status
    if timestamp_error:
        safe['report_timestamp_warning']='INVALID_OR_STALE_REPORT_TIMESTAMP'
    safe['fixtures']['matches']=window
    safe['fixtures']['events_truncated']=bool(window_limit) or len(raw)>MAX_PUBLIC_MATCHES
    status_payload={'checked_utc':report.get('checked_utc'), 'status':status,
        'public_fixture_sources_success':success,'public_fixture_sources_total':len(src_records),
        'sources_http_success':fetched,'window_matches':len(window),
        'events_truncated':safe['fixtures']['events_truncated'],
        'report_timestamp_warning':'INVALID_OR_STALE_REPORT_TIMESTAMP' if timestamp_error else None,
        'production_recommendations':'DISABLED'}
    with publish_lock(dest):
        atomic_write(dest/'index.html',content)
        atomic_write(dest/'report.json',json.dumps(safe,ensure_ascii=False,indent=2))
        atomic_write(dest/'status.json',json.dumps(status_payload,ensure_ascii=False,indent=2))
        atomic_write(dest/'.nojekyll','')
        atomic_write(dest/'freshness.js',CLIENT_FRESHNESS_JS)
    return dest/'index.html'

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',default='data/daily_report.json');p.add_argument('--out',default='site');a=p.parse_args()
    print(build(a.report,a.out))
