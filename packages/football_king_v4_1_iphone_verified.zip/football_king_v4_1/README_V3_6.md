# Football King V3.6 — keyless OpenFootball connector

Run: `python run.py openfootball --season 2026-27 --league epl --out fixtures.json`

Supported league aliases: epl, championship, bundesliga, laliga, seriea, ligue1.

Data license: OpenFootball football.json public domain; https://github.com/openfootball/football.json

IMPORTANT: Data may be stale. Fixtures are date-only with no kickoff time. No bookmaker odds, xG, confirmed lineups, or validated model probabilities. Research only; production recommendations disabled. Network access required; failure yields HOLD.

Run tests: `python run.py test`. No API key required.
