# Football King V3.7 — Keyless research operations

## ① Fixtures/results sync
`python sync_v37.py --season 2025-26 --league epl --out data/latest.json`

Uses public-domain OpenFootball JSON. Network access is required. If the source is unreachable, returns HOLD (exit 2), records failure, and does not claim fresh data. It is not a real-time odds/lineup source. Existing `run.py` commands remain available.

## ④ Calibration and ⑤ out-of-sample evaluation
`python -c "from research_v37 import evaluate; print(evaluate('YOUR_REAL_PREDICTIONS.csv'))"`

CSV columns: case_id,prediction_utc,kickoff_utc,p_home,p_draw,p_away,outcome. Predictions must be recorded **before** kickoff, not reconstructed after results. Chronological 60/20/20 split; train temperature tuning; validation selects calibrated versus raw; untouched test scores. Conservative label-leakage embargo. Small data or overlaps => HOLD. The demo sample is not evidence of real accuracy. No betting ROI/CLV unless historical timestamped odds are supplied.

## ⑥ Scheduling
GitHub Actions workflow `.github/workflows/keyless-sync.yml` runs daily and manually; saves output as artifact. Requires repository hosting, Actions enabled, and outbound access; cannot be launched persistently from ChatGPT. No API key needed. Cron does not guarantee exact minute.

## Unresolved ②③⑦
Licensed odds data, comprehensive lineup/injury/xG feeds, and original V2.8 source are missing. Production recommendations stay DISABLED. Source freshness and rights must be reviewed before operational use.

Existing sample_backtest.csv uses an older schema and cannot prove V3.7 calibration; use actual timestamped predictions in the documented schema.
