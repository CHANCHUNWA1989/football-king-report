"""Public-domain OpenFootball keyless JSON connector (fixtures/results, not live odds)."""
import hashlib, json, re
from datetime import date, datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

ROOT = "https://raw.githubusercontent.com/openfootball/football.json/master"
LEAGUES = {"epl":"en.1", "championship":"en.2", "bundesliga":"de.1", "laliga":"es.1", "seriea":"it.1", "ligue1":"fr.1"}

def fetch(season, league="epl", opener=urlopen, clock=None):
    if not re.fullmatch(r"20\d{2}-\d{2}", season) or int(season[-2:]) != (int(season[:4])+1)%100:
        raise ValueError("invalid season; expected YYYY-YY")
    if league not in LEAGUES: raise ValueError("unsupported league")
    url=f"{ROOT}/{season}/{LEAGUES[league]}.json"
    req=Request(url,headers={"User-Agent":"FootballKing/3.6 (+public-domain research)","Accept":"application/json"})
    try:
        with opener(req,timeout=15) as r:
            body=r.read(5_000_001)
        if len(body)>5_000_000: raise ValueError("oversized payload")
        payload=json.loads(body)
        if not isinstance(payload,dict) or not isinstance(payload.get("matches"),list): raise ValueError("invalid schema")
        out=[]; seen=set()
        for m in payload["matches"]:
            if not isinstance(m,dict): continue
            d,h,a=m.get("date"),m.get("team1"),m.get("team2")
            try: date.fromisoformat(d)
            except (TypeError,ValueError): continue
            if not isinstance(h,str) or not h.strip() or not isinstance(a,str) or not a.strip() or h==a: continue
            key=(d,h,a)
            if key in seen: continue
            seen.add(key)
            score=m.get("score") or {}; ft=score.get("ft") if isinstance(score,dict) else None
            if not (isinstance(ft,list) and len(ft)==2 and all(type(x)==int and x>=0 for x in ft)): ft=None
            out.append({"date":d,"home":h,"away":a,"score_ft":ft,"status":"FINISHED" if ft else "UNCONFIRMED","kickoff_utc":None})
        captured=(clock or (lambda:datetime.now(timezone.utc)))().isoformat()
        return {"status":"READY_RESEARCH" if out else "HOLD","reason":None if out else "NO_VALID_MATCHES","source":"openfootball/football.json","source_url":url,"captured_utc":captured,"sha256":hashlib.sha256(body).hexdigest(),"season":season,"league":league,"matches":out,"limitations":["source may be stale","date only; kickoff time unknown","no odds, xG or confirmed lineups","not verified against independent source"],"production_recommendations":"DISABLED"}
    except (HTTPError,URLError,TimeoutError,OSError,ValueError,TypeError,json.JSONDecodeError) as exc:
        return {"status":"HOLD","reason":type(exc).__name__,"source_url":url,"matches":[],"production_recommendations":"DISABLED"}
