"""Strict offline decision pipeline; never interprets illustrative estimates as validated bets."""
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from math import isfinite
from advanced import ensemble, parse_utc
from hardening import check_quote, probability

@dataclass
class ModelEvidence:
    calibrated: bool = False
    oos_evaluated: bool = False
    model_id: str = 'unverified'
    conservative_probability: float | None = None


def decide(case, quotes, models, weights, evidence, now_utc):
    """All timestamps ISO8601 offset-aware; no network access; no hidden defaults."""
    issues=[]
    now=parse_utc(now_utc)
    try:
        kickoff=parse_utc(case['kickoff_utc'])
        if now>=kickoff: issues.append('KICKOFF_PASSED')
        if not case.get('lineup_confirmed',False): issues.append('LINEUP_UNCONFIRMED')
        if case.get('market')!='1X2': issues.append('UNSUPPORTED_MARKET')
        selection=case['selection']
        if selection not in ('home','draw','away'): issues.append('INVALID_SELECTION')
        if not case.get('case_id') or not case.get('event_id'): issues.append('MISSING_CASE_ID')
    except (KeyError, ValueError, TypeError) as e:
        return {'status':'HOLD','issues':['INVALID_CASE',str(e)]}
    rejected=[]; matching=[]
    for q in quotes:
        try:
            prices=check_quote(q,now,case['event_id'])
            matching.append((q,prices))
        except (ValueError,TypeError,KeyError,OverflowError) as e:
            rejected.append({'source':q.get('source','unknown') if isinstance(q,dict) else 'unknown','reason':str(e)})
    if not matching: issues.append('NO_VALID_MATCHING_QUOTE')
    if len(matching)>1: issues.append('AMBIGUOUS_QUOTES_REQUIRE_EXPLICIT_SELECTION')
    if not evidence.calibrated or not evidence.oos_evaluated: issues.append('MODEL_NOT_VALIDATED')
    # User-supplied flags are not independent evidence of validated calibration.
    issues.append('UNVERIFIED_MODEL_ATTESTATION')
    if not isinstance(evidence.model_id,str) or not evidence.model_id.strip() or evidence.model_id=='unverified': issues.append('INVALID_MODEL_ID')
    try:
        p=probability(ensemble(models,weights)[selection])
    except (ValueError,KeyError,TypeError,ZeroDivisionError,OverflowError) as e:
        p=None; issues.append('INVALID_MODEL:'+str(e))
    quote,prices=matching[0] if len(matching)==1 else (None,None)
    odds=prices[selection] if prices is not None and selection in prices else None
    if odds is not None and odds<1.8: issues.append('BELOW_ODDS_POLICY')
    conservative=evidence.conservative_probability
    try: conservative=probability(conservative)
    except (ValueError,TypeError):
        conservative=None
        issues.append('MISSING_CONSERVATIVE_PROBABILITY')
    if p is not None and conservative is not None and conservative>p:
        issues.append('CONSERVATIVE_PROBABILITY_EXCEEDS_ESTIMATE')
    ev=(p*odds-1) if p is not None and odds is not None else None
    low_ev=(conservative*odds-1) if conservative is not None and odds is not None and 0<=conservative<=1 else None
    if low_ev is not None and low_ev<=0: issues.append('NO_CONSERVATIVE_EDGE')
    return {'case_id':case['case_id'],'status':'HOLD' if issues else 'PASS_CANDIDATE',
            'issues':issues,'selection':selection,'source':quote['source'] if quote else None,
            'odds':odds,'model_probability':p,'illustrative_ev':ev,
            'conservative_ev':low_ev,'model_id':evidence.model_id,
            'evaluated_utc':now.isoformat(), 'quote_rejections':rejected}
