# 足球王者 V3.1 — 獨立離線驗證版

此版本由 V3.0 研究版複製而來，不修改原 V2.8 或原 V3.0 檔案。

## 已實作
- Poisson、Dixon-Coles、Elo 強度指標、概率融合；尚未訓練真實參數
- 1X2 賠率去水、來源及時間戳檢查、跨賽事隔離
- 嚴格決策閘門：正選、賽事、報價時效、模型校準、樣本外驗證、保守 EV
- 逐次決策 JSONL 審計日誌與 SHA256 記錄摘要
- T−180／60／20／10／0 時間表產生器；需要外部排程觸發
- 1X2 回測指標：Log Loss、Brier、簡單 ROI；不包含亞洲盤或交易成本

## 執行
在本資料夾：

```bash
python -m unittest discover -s tests -v
python monitor.py sample_pipeline.json --now 2026-10-08T12:00:00Z --log demo_audit.jsonl
python engine.py backtest sample_backtest.csv
```

## 尚未接通
未取得合法即時賠率、xG、正選、傷停、歷史訓練數據、外部排程執行環境，亦未取得 V2.8 原始檔案。所有示範資料均為合成資料；不可視為真實推薦、已驗證獲利或全自動上線。

`PASS_CANDIDATE` 只表示本地輸入通過程式閘門，**不是**已確認可交易或已經人工覆核。
