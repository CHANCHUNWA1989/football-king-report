# 足球王者 V3.5 — 可執行本地版

啟動前不需要 API key 即可做本地自檢與測試：

```bash
python run.py check
python run.py test
python run.py fixtures
```

要取得官方賽程，先在 https://www.football-data.org/client/register 註冊並取得授權金鑰，設定 `FOOTBALL_DATA_API_KEY`，再執行 `python run.py fixtures --out fixtures.json`。賽程缺少賠率、xG 和確認陣容，**不能當作已驗證投注推薦**。沒有 API Key 時，賽程執行回傳 HOLD 並以 exit code 2 結束。此程式只會在使用者主動執行時運行，沒有全天候服務。
