"""Run a single local scheduled check. Cron/cloud worker must invoke this externally."""
import argparse,json
from pathlib import Path
from dataclasses import asdict
from pipeline import ModelEvidence,decide
from audit import append_record

def main():
    p=argparse.ArgumentParser();p.add_argument('input_json');p.add_argument('--now',required=True);p.add_argument('--log',default='audit.jsonl')
    a=p.parse_args();d=json.loads(Path(a.input_json).read_text(encoding='utf8'))
    r=decide(d['case'],d['quotes'],d['models'],d['weights'],ModelEvidence(**d.get('evidence',{})),a.now)
    append_record(a.log,r)
    print(json.dumps(r,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
