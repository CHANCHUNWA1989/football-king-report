"""Check generated Pages artifacts without treating research data as live betting evidence.

Exit 0: structurally valid, recent RESEARCH_ONLY report.
Exit 2: structurally valid HOLD/expired/empty report (expected on source outage).
Exit 1: missing, malformed, inconsistent or unsafe artifact.
"""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def inspect(site, now=None):
    site=Path(site)
    required=('index.html','report.json','status.json','freshness.js')
    absent=[name for name in required if not (site/name).is_file()]
    if absent:
        return {'result':'ERROR','reason':'MISSING_SITE_ASSETS','missing':absent}
    try:
        if (site/'report.json').stat().st_size>16_000_000:
            raise ValueError('OVERSIZE_REPORT')
        report=json.loads((site/'report.json').read_text(encoding='utf-8'))
        state=json.loads((site/'status.json').read_text(encoding='utf-8'))
        html=(site/'index.html').read_text(encoding='utf-8')
        if not isinstance(report,dict) or not isinstance(state,dict):
            raise ValueError('INVALID_SITE_SCHEMA')
        if not all(report.get('production_recommendations')=='DISABLED' for _ in (0,)) or state.get('production_recommendations')!='DISABLED':
            raise ValueError('UNSAFE_RECOMMENDATION_FLAG')
        if report.get('status')!=state.get('status') or report.get('checked_utc')!=state.get('checked_utc'):
            raise ValueError('INCONSISTENT_PUBLIC_STATUS')
        if '足球王者' not in html or '正式投注推薦：停用' not in html:
            raise ValueError('MISSING_SAFETY_NOTICE')
        if state['status'] not in ('HOLD','RESEARCH_ONLY'):
            raise ValueError('UNEXPECTED_STATUS')
        clock=now or datetime.now(timezone.utc)
        if clock.tzinfo is None: raise ValueError('BAD_CURRENT_TIME')
        try:
            checked=datetime.fromisoformat(str(state['checked_utc']).replace('Z','+00:00'))
            if checked.tzinfo is None: raise ValueError('NAIVE_TIMESTAMP')
            seconds=(clock-checked).total_seconds()
            fresh=-300<=seconds<=36*3600
        except (TypeError,ValueError,KeyError,OverflowError):
            fresh=False
        effective='RESEARCH_ONLY' if state['status']=='RESEARCH_ONLY' and fresh else 'HOLD'
        if not fresh and state['status']=='RESEARCH_ONLY':
            raise ValueError('STORED_SUCCESS_HAS_EXPIRED')
        matches=report.get('fixtures',{}).get('matches',[])
        if not isinstance(matches,list) or len(matches)>1200:
            raise ValueError('BAD_MATCH_LIST')
        return {'result':effective,'reason':'CHECKED_PUBLIC_ARTIFACTS',
                'matches':len(matches),'checked_utc':state.get('checked_utc'),
                'production_recommendations':'DISABLED'}
    except (ValueError,TypeError,KeyError,OSError,json.JSONDecodeError) as exc:
        return {'result':'ERROR','reason':str(exc)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--site',default='site')
    result=inspect(p.parse_args().site)
    print(json.dumps(result,ensure_ascii=False))
    return {'RESEARCH_ONLY':0,'HOLD':2}.get(result['result'],1)

if __name__=='__main__':raise SystemExit(main())
