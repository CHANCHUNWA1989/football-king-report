"""Integrated A/B/C research pipeline. No claim of live bookmaker feeds or certified picks."""
import argparse, json, os, sys
from pathlib import Path
from datetime import datetime, timezone
from openfootball import fetch
from fixture_gateway import current_season
from fixture_safety import compact_matches
from integrations_v38 import import_odds, import_team_info
from research_v37 import evaluate


def run(season=None, league='epl', odds=None, team=None, history=None, offline=None, now=None, fixture_override=None):
    now=now or datetime.now(timezone.utc)
    season=season or current_season(now)
    if fixture_override is not None:
        fixture=dict(fixture_override)
        fixture.setdefault('origin','PUBLIC_KEYLESS_NETWORK')
        fixture.setdefault('verified_live',False)
    elif offline:
        fixture=json.loads(Path(offline).read_text(encoding='utf-8'))
        fixture={**fixture, 'origin':'USER_SUPPLIED_OFFLINE', 'verified_live':False}
    else:
        fixture=fetch(season,league,clock=lambda:now)
        fixture['origin']='PUBLIC_KEYLESS_NETWORK'
        fixture['verified_live']=False  # independent verification is not implemented
    # Untrusted and offline reports also need date-window and schema validation.
    safe_matches,limit_reason=compact_matches(fixture.get('matches'),now=now)
    fixture['matches']=safe_matches
    if limit_reason:
        fixture['safety_reason']=limit_reason
    from fixture_safety import capture_age_error
    capture_error=capture_age_error(fixture.get('captured_utc'),now)
    if capture_error:
        fixture['safety_reason']=capture_error
        fixture['status']='HOLD'
        fixture['reason']=capture_error
    if limit_reason in ('CONFLICTING_EVENT_IDENTITIES','SOURCE_EVENT_LIMIT_EXCEEDED'):
        fixture['status']='HOLD'
        fixture['reason']=limit_reason
    if not safe_matches and fixture.get('status')=='READY_RESEARCH':
        fixture['status']='HOLD'
        fixture['reason']=limit_reason or 'NO_MATCHES_IN_CURRENT_WINDOW'
    checks={}
    # A positive source response is not evidence that the current window has valid matches.
    # Never upgrade a HOLD fixture collection just because it contains historical rows.
    fixture_usable = bool(safe_matches) and not limit_reason and (
        fixture.get('status') == 'READY_RESEARCH' or
        (fixture.get('origin') == 'USER_SUPPLIED_OFFLINE' and 'status' not in fixture))
    checks['A_fixtures']={'status':'RESEARCH_ONLY' if fixture_usable else 'HOLD',
                          'count':len(fixture.get('matches',[])), 'reason':fixture.get('reason')}
    odds_error=None
    try: odds_result=import_odds(odds,now=now) if odds else None
    except (OSError,ValueError,TypeError) as exc:
        odds_result=None
        odds_error=type(exc).__name__
    quotes=odds_result['accepted'] if odds_result else []
    books={q['bookmaker'] for q in quotes}
    # Compare only the SAME event, market, line and selection; bookmaker count
    # across unrelated events must NEVER signal that two books agree.
    from collections import defaultdict
    matched=defaultdict(set)
    for q in quotes:
        key=(q['event_id'],q['market'],q['line'],q['selection'])
        matched[key].add(q['bookmaker'])
    comparable_groups=sum(len(v)>=2 for v in matched.values())
    checks['B_odds']={'status':'RESEARCH_ONLY' if comparable_groups else 'HOLD',
                      'bookmakers':len(books),'quotes':len(quotes),
                      'comparable_groups':comparable_groups,
                      'reason':'IMPORTED_QUOTES_NOT_LIVE_VERIFIED' if comparable_groups else (odds_error or 'NO_VERIFIED_COMPARABLE_MARKET')}
    team_error=None
    try: team_result=import_team_info(team,now=now) if team else None
    except (OSError,ValueError,TypeError) as exc:
        team_result=None
        team_error=type(exc).__name__
    checks['B_team_info']={'status':'RESEARCH_ONLY' if team_result and team_result['accepted'] else 'HOLD',
                           'records':len(team_result['accepted']) if team_result else 0,
                           'reason':team_error if team_error else None}
    try:
        calibration=evaluate(history) if history else None
    except (ValueError,TypeError,ZeroDivisionError,OSError) as e:
        calibration={'status':'HOLD','reason':str(e)}
    checks['C_calibration']={'status':calibration['status'] if calibration else 'HOLD',
                             'reason':calibration.get('reason','RESEARCH_ONLY_NOT_CERTIFIED') if calibration else 'NO_HISTORICAL_DATA'}
    checks['C_deployment']={'status':'HOLD','reason':'LOCAL_RUN_NOT_PROOF_OF_SCHEDULED_CLOUD_DEPLOYMENT'}
    checks['legacy_v28']={'status':'HOLD','reason':'ORIGINAL_SOURCE_NOT_PROVIDED'}
    return {'version':'4.0-release-candidate','checked_utc':now.isoformat(),
            'status':'RESEARCH_ONLY' if fixture_usable else 'HOLD',
            'production_recommendations':'DISABLED', 'checks':checks,
            'fixtures':fixture, 'odds':odds_result, 'team_info':team_result,
            'calibration':calibration,
            'warnings':['No verified live bookmaker feed','No independent fixture verification',
                        'No 24/7 service has been deployed','No proven profitable model']}

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--season',default=None);p.add_argument('--league',default='epl')
    p.add_argument('--odds');p.add_argument('--team');p.add_argument('--history')
    p.add_argument('--offline');p.add_argument('--out',default='data/integrated_report.json')
    a=p.parse_args(argv)
    result=run(a.season,a.league,a.odds,a.team,a.history,a.offline)
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':result['checks'],'report':str(dest)},ensure_ascii=False))
    return 0 if result['status']=='RESEARCH_ONLY' else 2
if __name__=='__main__':sys.exit(main())
