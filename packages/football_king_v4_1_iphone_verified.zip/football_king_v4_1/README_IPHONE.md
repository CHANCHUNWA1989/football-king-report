# 足球王者 iPhone 每日報告（GitHub Pages）

## 手機首次設定（毋須 API Key）
1. 用 GitHub 網站建立 **私人** 或公開儲存庫；上傳本 ZIP 解壓後 `football_king_mobile` 內所有檔案（包含隱藏的 `.github` 目錄）。注意：GitHub Pages 發佈網站可能是**公開可見**，不要上傳私人投注資料或密鑰。
2. 進入 GitHub 儲存庫 Settings → Pages → Build and deployment → Source 選 **GitHub Actions**。
3. 進入 Actions → `Football King iPhone report` → Run workflow，等待綠色成功標記。
4. 到 Settings → Pages 開啟提供的網站 URL；iPhone Safari 用「分享」→「加入主畫面」。
5. 工作流程預設每天香港時間 09:17 嘗試執行；GitHub 排程可能延遲或被停用，並非即時監控。

## 真實性與限制
- 未授權賠率/正選/xG、沒有獨立核實的比賽資料，系統維持 HOLD；網站不會生成正式投注推薦。
- GitHub Pages 的網站內容是靜態報告，不是手機背景運行 Python。
- 網絡或來源失敗時，仍會生成 HOLD 報告，並顯示最新檢查時間。
- V2.8 原始碼仍未提供；舊版完整兼容未驗證。
- 若 GitHub Actions 執行失敗，網站可能停留在上一版；請核對頁面 UTC 更新時間及 Actions 紀錄。

## 本地測試
`python -m unittest discover -s tests -q`
`python integrated.py --offline sample_snapshot.json --out data/integrated_report.json`
`python mobile_site.py --report data/integrated_report.json --out site`
開啟 `site/index.html`。
