"""Normalize untrusted fixture data; enforce small public-report resource budgets.

Research-only. Never infer accuracy or claim bookmaker coverage.
"""
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

HK=ZoneInfo('Asia/Hong_Kong')
MAX_INPUT_PER_LEAGUE=20000
MAX_RECENT_PER_LEAGUE=750
MAX_PUBLIC_MATCHES=1200
MAX_PUBLIC_SOURCE_RECORDS=20
MAX_FIELD_LENGTH=160


def _text(value,limit=MAX_FIELD_LENGTH):
    if not isinstance(value,str): return None
    value=value.strip()
    if not value or len(value)>limit or any(ord(c)<32 for c in value): return None
    return value


def _score(value):
    if isinstance(value,list) and len(value)==2 and all(type(v) is int and 0<=v<=99 for v in value):
        return list(value)
    return None


def normalize_match(row, now, past_days=2, future_days=21):
    """Validate one row. Return None if unsafe, malformed or outside date window."""
    if not isinstance(row,dict): return None
    if not isinstance(now,datetime) or now.tzinfo is None: raise ValueError('AWARE_NOW_REQUIRED')
    day=_text(row.get('date'),10)
    if day is None: return None
    try: parsed=date.fromisoformat(day)
    except ValueError: return None
    if parsed.isoformat()!=day: return None
    today=now.astimezone(HK).date()
    if not today-timedelta(days=past_days)<=parsed<=today+timedelta(days=future_days): return None
    home=_text(row.get('home'),100)
    away=_text(row.get('away'),100)
    if not home or not away or home.casefold()==away.casefold(): return None
    ko=row.get('kickoff_utc')
    if ko is not None:
        ko=_text(ko,48)
        if not ko: return None
        try:
            dt=datetime.fromisoformat(ko.replace('Z','+00:00'))
            if dt.tzinfo is None: return None
            dt=dt.astimezone(timezone.utc)
            if dt.astimezone(HK).date()!=parsed: return None
            ko=dt.isoformat()
        except (ValueError,OverflowError): return None
    score=_score(row.get('score_ft'))
    state=_text(row.get('status'),32) or 'UNCONFIRMED'
    if state not in ('SCHEDULED','FINISHED','FINISHED_UNSCORED','UNCONFIRMED','POSTPONED','CANCELLED'):
        state='UNCONFIRMED'
    event_id=_text(row.get('event_id'),100)
    return {'date':day,'home':home,'away':away,'score_ft':score,'status':state,
            'kickoff_utc':ko,'event_id':event_id}


def capture_age_error(value, now, *, max_age_hours=36, future_skew_minutes=5):
    """A dated source snapshot must be fresh; missing evidence stays unverified.

    This deliberately does not treat captured_utc as the upstream publication time.
    """
    if value is None:
        return None  # legacy/offline fixture schema; NOT proof of live freshness
    if not isinstance(value, str):
        return 'INVALID_SOURCE_CAPTURE_TIME'
    try:
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
        if stamp.tzinfo is None:
            return 'INVALID_SOURCE_CAPTURE_TIME'
        seconds=(now.astimezone(timezone.utc)-stamp.astimezone(timezone.utc)).total_seconds()
    except (ValueError, TypeError, OverflowError):
        return 'INVALID_SOURCE_CAPTURE_TIME'
    if seconds < -future_skew_minutes*60:
        return 'SOURCE_CAPTURE_IN_FUTURE'
    if seconds > max_age_hours*3600:
        return 'STALE_SOURCE_CAPTURE'
    return None


def compact_matches(rows,now,max_output=MAX_RECENT_PER_LEAGUE):
    """Fail closed on invalid container or extreme volume; avoid O(n) JSON copying."""
    if not isinstance(rows,list): return [],'BAD_MATCHES_SCHEMA'
    if len(rows)>MAX_INPUT_PER_LEAGUE: return [],'SOURCE_EVENT_LIMIT_EXCEEDED'
    unique={}; invalid=0; conflicted=set()
    for row in rows:
        item=normalize_match(row,now)
        if item is None:
            invalid+=1
            continue
        key=('id',item['event_id']) if item['event_id'] else ('fixture',item['date'],item['home'].casefold(),item['away'].casefold())
        if key in conflicted:
            continue
        previous=unique.get(key)
        if previous is None:
            unique[key]=item
        elif item['event_id'] and (previous['date'],previous['home'].casefold(),previous['away'].casefold()) != (item['date'],item['home'].casefold(),item['away'].casefold()):
            conflicted.add(key)
            del unique[key]  # both records are untrustworthy
    output=sorted(unique.values(),key=lambda m:(m['date'],m['kickoff_utc'] or '',m['home'],m['away']))
    if conflicted:
        return output[:max_output], 'CONFLICTING_EVENT_IDENTITIES'
    if len(output)>max_output:
        return output[:max_output],'REPORT_EVENT_LIMIT_EXCEEDED'
    return output,None
