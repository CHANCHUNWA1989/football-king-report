"""Offline research modules: no live API connections or verified calibration."""
from math import exp, factorial, isfinite
from datetime import datetime, timezone, timedelta

def devig(odds):
    if set(odds) != {'home','draw','away'} or any(not isfinite(float(x)) or not 1<float(x)<100 for x in odds.values()): raise ValueError('Invalid 1X2 odds')
    raw={k:1/float(v) for k,v in odds.items()}; z=sum(raw.values())
    return {k:v/z for k,v in raw.items()}

def dixon_coles(h,a,rho,max_goals=12):
    if not all(isfinite(float(v)) for v in (h,a,rho)) or not (0<h<=8 and 0<a<=8 and -.3<=rho<=.3): raise ValueError('Invalid parameters')
    result={'home':0.,'draw':0.,'away':0.}
    for i in range(max_goals+1):
        for j in range(max_goals+1):
            tau={(0,0):1-h*a*rho,(0,1):1+h*rho,(1,0):1+a*rho,(1,1):1-rho}.get((i,j),1)
            if tau<0: raise ValueError('Negative adjustment')
            p=exp(-h-a)*h**i*a**j/factorial(i)/factorial(j)*tau
            result['home' if i>j else 'draw' if i==j else 'away']+=p
    z=sum(result.values());return {k:v/z for k,v in result.items()}

def ensemble(models,weights):
    if not models or len(models)!=len(weights) or any(not isfinite(w) or w<0 for w in weights) or abs(sum(weights)-1)>1e-8: raise ValueError('Invalid weights')
    keys={'home','draw','away'}
    for m in models:
        if set(m)!=keys or any(not isfinite(v) or not 0<=v<=1 for v in m.values()) or abs(sum(m.values())-1)>1e-6: raise ValueError('Invalid probabilities')
    return {k:sum(w*m[k] for w,m in zip(weights,models)) for k in keys}

def elo_home_strength(home,away,home_advantage=60):
    return 1/(1+10**(-(home+home_advantage-away)/400))

def parse_utc(value):
    d=datetime.fromisoformat(value.replace('Z','+00:00'))
    if d.tzinfo is None: raise ValueError('Missing timezone')
    return d.astimezone(timezone.utc)

def validate_quotes(quotes,now_utc,max_age_minutes=20):
    now=parse_utc(now_utc);valid=[];rejected=[]
    for q in quotes:
        try:
            age=(now-parse_utc(q['captured_utc'])).total_seconds()/60
            if not 0<=age<=max_age_minutes: raise ValueError('Stale/future')
            if not q.get('source') or not q.get('event_id'): raise ValueError('Missing provenance')
            prices={k:q[k] for k in ('home','draw','away')}
            valid.append({'source':q['source'],'event_id':q['event_id'],'fair':devig(prices)})
        except (KeyError,ValueError,TypeError) as e: rejected.append({'source':q.get('source','unknown'),'reason':str(e)})
    if len({q['event_id'] for q in valid})>1:
        rejected.extend({'source':q['source'],'reason':'Mixed event IDs'} for q in valid);valid=[]
    return {'status':'READY' if valid else 'HOLD','valid':valid,'rejected':rejected}

def trigger_schedule(kickoff_utc):
    d=parse_utc(kickoff_utc)
    return {f'T-{m}':(d-timedelta(minutes=m)).isoformat() for m in (180,60,20,10,0)}
