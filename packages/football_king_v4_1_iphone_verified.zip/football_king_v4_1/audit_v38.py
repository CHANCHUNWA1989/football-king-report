import argparse,json
from integrations_v38 import audit
p=argparse.ArgumentParser();p.add_argument('--odds');p.add_argument('--team-info');p.add_argument('--legacy');p.add_argument('--history');p.add_argument('--out',default='data/readiness.json')
a=p.parse_args();from pathlib import Path
r=audit(Path(__file__).parent,a.odds,a.team_info,a.legacy,a.history)
t=Path(a.out);t.parent.mkdir(parents=True,exist_ok=True);t.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(r,ensure_ascii=False,indent=2))
