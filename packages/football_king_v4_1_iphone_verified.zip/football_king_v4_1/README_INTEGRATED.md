# Football King A+B+C integrated research edition

## Local run

`python -m unittest discover -s tests -q`

`python integrated.py --season 2026-27 --league epl --out data/integrated_report.json`

Optional authorized local data: `--odds odds.csv --team team.csv --history predictions.csv`. See `integrations_v38.py` and `research_v37.py` for CSV schemas.

Offline test: `python integrated.py --offline sample_snapshot.json --out data/offline_report.json` (offline fixture JSON must include a `matches` array).

## Deployment

Copy the repository to GitHub and enable Actions. The workflow is a *daily* scheduled research job, **not** a continuously running 24-hour service. GitHub scheduled jobs may be delayed. No deployment is claimed until a run is observed in your account.

## Explicit limitations

- OpenFootball may be stale, date-only, or unavailable from some networks.
- Odds and team info are **authorized CSV imports**, not live bookmaker scraping. No live bookmaker integration is claimed.
- Historical calibration requires authentic historical predictions and labels, not fabricated data.
- `production_recommendations` stays `DISABLED` regardless of tests.
- V2.8 migration requires original code.
