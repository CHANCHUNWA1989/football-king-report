import unittest,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pipeline import ModelEvidence,decide
from audit import append_record

class PipelineTests(unittest.TestCase):
 def setUp(self):
  self.case={'case_id':'DEMO','event_id':'EV1','kickoff_utc':'2026-10-09T12:00:00Z','lineup_confirmed':True,'market':'1X2','selection':'home'}
  self.quotes=[{'event_id':'EV1','source':'DEMO','captured_utc':'2026-10-08T11:55:00Z','home':2.2,'draw':3.2,'away':3.8}]
  self.models=[{'home':.55,'draw':.25,'away':.2}]
  self.evidence=ModelEvidence(True,True,'demo',.5)
 def run_case(self):return decide(self.case,self.quotes,self.models,[1],self.evidence,'2026-10-08T12:00:00Z')
 def test_candidate(self):self.assertEqual(self.run_case()['status'],'HOLD');self.assertIn('UNVERIFIED_MODEL_ATTESTATION',self.run_case()['issues'])
 def test_missing_validation_hold(self):
  self.evidence.calibrated=False;self.assertEqual(self.run_case()['status'],'HOLD')
 def test_wrong_event_hold(self):
  self.quotes[0]['event_id']='EV2';self.assertEqual(self.run_case()['status'],'HOLD')
 def test_stale_hold(self):
  self.quotes[0]['captured_utc']='2026-10-08T11:00:00Z';self.assertEqual(self.run_case()['status'],'HOLD')
 def test_low_edge_hold(self):
  self.evidence.conservative_probability=.4;self.assertEqual(self.run_case()['status'],'HOLD')
 def test_no_lineup_hold(self):
  self.case['lineup_confirmed']=False;self.assertEqual(self.run_case()['status'],'HOLD')
 def test_audit_append(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'audit.jsonl';append_record(p,{'case_id':'DEMO','status':'HOLD'})
   self.assertEqual(len(p.read_text().splitlines()),1)
