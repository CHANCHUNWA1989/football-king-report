import unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import probabilities, evaluate_csv, assess, Snapshot
class EngineTests(unittest.TestCase):
 def test_probabilities(self):
  p=probabilities(1.4,1.1)
  self.assertAlmostEqual(sum(p.values()),1)
 def test_backtest(self):
  r=evaluate_csv(Path(__file__).resolve().parents[1]/'sample_backtest.csv')
  self.assertEqual(r['n'],2)
  self.assertEqual(r['bets'],1)
 def test_uncalibrated_hold(self):
  import json
  p=Path(__file__).resolve().parents[1]/'sample_snapshot.json'
  r=assess(Snapshot(**json.loads(p.read_text())))
  self.assertEqual(r['status'],'HOLD')
if __name__=='__main__':unittest.main()
