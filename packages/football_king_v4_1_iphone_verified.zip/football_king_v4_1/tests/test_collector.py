import unittest,sys,json
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from collector import collect
class FakeResponse:
 def __enter__(self): return self
 def __exit__(self,*args): pass
 def read(self,n): return json.dumps({'matches':[{'id':123,'utcDate':'2026-10-09T12:00:00Z','status':'SCHEDULED','homeTeam':{'name':'A'},'awayTeam':{'name':'B'}}]}).encode()
class CollectorTests(unittest.TestCase):
 def test_no_token_hold(self):
  from unittest.mock import patch
  with patch.dict('os.environ',{},clear=True):
   self.assertEqual(collect('2026-10-08','2026-10-08')['status'],'HOLD')
 def test_invalid_date(self):
  with self.assertRaises(ValueError):collect('2026-10-10','2026-10-08',token='demo')
 def test_long_range(self):
  with self.assertRaises(ValueError):collect('2026-10-01','2026-10-15',token='demo')
 def test_mock_api(self):
  r=collect('2026-10-08','2026-10-09',token='demo',opener=lambda *a,**k:FakeResponse(),clock=lambda:datetime(2026,10,8,tzinfo=timezone.utc))
  self.assertEqual(r['status'],'READY');self.assertEqual(r['matches'][0]['event_id'],'123')
  self.assertIn('no live odds',r['limitations'])
