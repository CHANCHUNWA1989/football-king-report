import json
import tempfile
import unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
from mobile_site import build
from healthcheck import inspect

NOW=datetime(2026,10,8,15,tzinfo=timezone.utc)

class HealthcheckTests(unittest.TestCase):
    def page(self, root, status='RESEARCH_ONLY'):
        root=Path(root)
        p=root/'input.json'
        p.write_text(json.dumps({'status':status,'checked_utc':NOW.isoformat(),
             'fixtures':{'matches':[{'date':'2026-10-09','home':'A','away':'B'}]}}))
        build(p,root/'site',wall_clock=NOW)
        return root/'site'

    def test_valid_research(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(inspect(self.page(d),now=NOW)['result'],'RESEARCH_ONLY')

    def test_valid_hold(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(inspect(self.page(d,'HOLD'),now=NOW)['result'],'HOLD')

    def test_missing_asset(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(inspect(d)['reason'],'MISSING_SITE_ASSETS')

    def test_detect_status_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            site=self.page(d)
            path=site/'status.json'
            obj=json.loads(path.read_text())
            obj['status']='HOLD'
            path.write_text(json.dumps(obj))
            self.assertEqual(inspect(site,now=NOW)['result'],'ERROR')

    def test_expired_success_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            site=self.page(d)
            self.assertEqual(inspect(site,now=NOW+timedelta(days=3))['reason'],'STORED_SUCCESS_HAS_EXPIRED')

    def test_betting_flag_not_allowed(self):
        with tempfile.TemporaryDirectory() as d:
            site=self.page(d)
            path=site/'report.json'
            obj=json.loads(path.read_text())
            obj['production_recommendations']='ENABLED'
            path.write_text(json.dumps(obj))
            self.assertEqual(inspect(site,now=NOW)['reason'],'UNSAFE_RECOMMENDATION_FLAG')
