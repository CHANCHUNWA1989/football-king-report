import io,json,unittest
from openfootball import fetch
class Response:
 def __init__(self,data): self.data=data
 def __enter__(self): return self
 def __exit__(self,*args): pass
 def read(self,n): return self.data[:n]
class Tests(unittest.TestCase):
 def test_normal(self):
  data=json.dumps({'matches':[{'date':'2026-10-08','team1':'A','team2':'B','score':{'ft':[2,1]}},{'date':'2026-10-09','team1':'C','team2':'D'}]}).encode()
  r=fetch('2026-27',opener=lambda *a,**kw:Response(data))
  self.assertEqual(r['status'],'READY_RESEARCH');self.assertEqual(len(r['matches']),2);self.assertEqual(r['matches'][0]['score_ft'],[2,1]);self.assertIsNone(r['matches'][1]['kickoff_utc'])
 def test_duplicate_and_bad_rows(self):
  x={'date':'2026-10-08','team1':'A','team2':'B'}
  r=fetch('2026-27',opener=lambda *a,**kw:Response(json.dumps({'matches':[x,x,{'date':'bad','team1':'X','team2':'Y'}]}).encode()))
  self.assertEqual(len(r['matches']),1)
 def test_bad_schema_hold(self):
  r=fetch('2026-27',opener=lambda *a,**kw:Response(b'{}'))
  self.assertEqual(r['status'],'HOLD')
 def test_network_hold(self):
  def fail(*args,**kwargs): raise OSError('offline')
  self.assertEqual(fetch('2026-27',opener=fail)['status'],'HOLD')
 def test_bad_season(self):
  with self.assertRaises(ValueError): fetch('2026-99')
 def test_bad_league(self):
  with self.assertRaises(ValueError): fetch('2026-27','wrong')
if __name__=='__main__':unittest.main()
