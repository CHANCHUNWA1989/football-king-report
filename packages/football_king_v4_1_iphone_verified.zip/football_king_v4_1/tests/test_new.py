import unittest,sys,tempfile,csv
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from settlement import settle
from validation import report
class NewTests(unittest.TestCase):
 def test_ah_full_win(self):self.assertAlmostEqual(settle('AH','home',-.5,2,1,1.9),.9)
 def test_ah_half_win(self):self.assertAlmostEqual(settle('AH','home',-.75,2,1,2),.5)
 def test_ah_half_loss(self):self.assertAlmostEqual(settle('AH','home',-.25,1,1,2),-.5)
 def test_ou_push(self):self.assertEqual(settle('OU','over',2,1,1,2),0)
 def test_ou_under_half_win(self):self.assertAlmostEqual(settle('OU','under',2.25,1,1,2),.5)
 def test_invalid_line(self):
  with self.assertRaises(ValueError):settle('AH','home',-.3,2,1,2)
 def test_validation(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.csv';p.write_text('case_id,prediction_utc,kickoff_utc,p_home,p_draw,p_away,outcome\na,2026-01-01T00:00:00Z,2026-01-02T00:00:00Z,0.5,0.3,0.2,home\n')
   self.assertFalse(report(p)['minimum_met'])
 def test_leakage_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'x.csv';p.write_text('case_id,prediction_utc,kickoff_utc,p_home,p_draw,p_away,outcome\na,2026-01-03T00:00:00Z,2026-01-02T00:00:00Z,0.5,0.3,0.2,home\n')
   with self.assertRaises(ValueError):report(p)
