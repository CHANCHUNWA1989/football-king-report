import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from advanced import devig,dixon_coles,ensemble,validate_quotes,trigger_schedule,elo_home_strength
class AdvancedTests(unittest.TestCase):
 def test_devig(self): self.assertAlmostEqual(sum(devig({'home':2,'draw':3.5,'away':4}).values()),1)
 def test_dc(self): self.assertAlmostEqual(sum(dixon_coles(1.5,1.2,-.1).values()),1)
 def test_ensemble(self):
  x={'home':.5,'draw':.3,'away':.2};self.assertEqual(ensemble([x,x],[.4,.6]),x)
 def test_stale_hold(self):
  q=[{'event_id':'demo','source':'test','captured_utc':'2020-01-01T00:00:00Z','home':2,'draw':3,'away':4}]
  self.assertEqual(validate_quotes(q,'2026-10-08T12:00:00Z')['status'],'HOLD')
 def test_schedule(self): self.assertEqual(len(trigger_schedule('2026-10-09T12:00:00Z')),5)
 def test_elo(self): self.assertTrue(0<elo_home_strength(1500,1500)<1)
