import unittest,tempfile,csv
from pathlib import Path
from datetime import datetime,timezone
from integrations_v38 import import_odds,import_team_info,audit
class V38Tests(unittest.TestCase):
 def test_odds_good(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'o.csv';p.write_text('event_id,bookmaker,market,line,selection,decimal_odds,observed_utc,source_url\nE1,Book A,over_under,2.5,over,1.95,2026-10-08T12:00:00Z,https://example.org/odds\n')
   r=import_odds(p,now=datetime(2026,10,8,12,5,tzinfo=timezone.utc));self.assertEqual(len(r['accepted']),1)
 def test_odds_stale(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'o.csv';p.write_text('event_id,bookmaker,market,line,selection,decimal_odds,observed_utc,source_url\nE1,B,1x2,,home,1.9,2026-10-07T12:00:00Z,https://example.org/odds\n')
   self.assertEqual(import_odds(p,now=datetime(2026,10,8,12,5,tzinfo=timezone.utc))['status'],'HOLD')
 def test_invalid_line(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'o.csv';p.write_text('event_id,bookmaker,market,line,selection,decimal_odds,observed_utc,source_url\nE1,B,over_under,2.3,over,1.9,2026-10-08T12:00:00Z,https://example.org/odds\n')
   self.assertEqual(import_odds(p,now=datetime(2026,10,8,12,5,tzinfo=timezone.utc))['status'],'HOLD')
 def test_team_info(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'t.csv';p.write_text('event_id,team,kind,status,observed_utc,source_url\nE1,A,lineup,confirmed,2026-10-08T12:00:00Z,https://example.org/news\n')
   self.assertEqual(len(import_team_info(p,now=datetime(2026,10,8,13,tzinfo=timezone.utc))['accepted']),1)
 def test_audit_fail_closed(self):
  with tempfile.TemporaryDirectory() as t:
   r=audit(t);self.assertEqual(len(r['checks']),7);self.assertEqual(r['status'],'HOLD')
if __name__=='__main__':unittest.main()
