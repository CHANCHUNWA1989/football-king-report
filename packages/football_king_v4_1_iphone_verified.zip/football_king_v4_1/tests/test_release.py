import json, tempfile, unittest, csv
from datetime import datetime, timezone
from pathlib import Path
from fixture_gateway import current_season, fetch_openligadb, get_fixtures, select_window
from daily_publish import collect_daily, publish
from integrated import run

NOW=datetime(2026,10,8,10,0,tzinfo=timezone.utc)

class Response:
    def __init__(self,data):self.data=data
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n):return self.data[:n]

def oldb_data():
    return json.dumps([
      {'matchID':21,'team1':{'teamName':'Bayern'},'team2':{'teamName':'Dortmund'},
       'matchDateTimeUTC':'2026-10-09T18:00:00Z','matchIsFinished':False,'matchResults':[]},
      {'matchID':22,'team1':{'teamName':'Leipzig'},'team2':{'teamName':'Bochum'},
       'matchDateTimeUTC':'2026-10-07T18:00:00Z','matchIsFinished':True,
       'matchResults':[{'resultTypeID':1,'pointsTeam1':1,'pointsTeam2':0},
                       {'resultTypeID':2,'pointsTeam1':2,'pointsTeam2':1}]}
    ]).encode()

class ReleaseTests(unittest.TestCase):
    def test_season_rollover_hk(self):
        self.assertEqual(current_season(datetime(2027,6,30,15,59,tzinfo=timezone.utc)),'2026-27')
        self.assertEqual(current_season(datetime(2027,6,30,16,1,tzinfo=timezone.utc)),'2027-28')
    def test_openligadb_parse(self):
        r=fetch_openligadb('2026-27',opener=lambda *a,**kw:Response(oldb_data()),clock=lambda:NOW)
        self.assertEqual(r['status'],'READY_RESEARCH')
        self.assertEqual(r['matches'][0]['event_id'],'openligadb:21')
        self.assertEqual(r['matches'][1]['score_ft'],[2,1])
        self.assertEqual(r['matches'][1]['date'],'2026-10-08')
        self.assertFalse(r['matches'][0]['score_ft'])
        self.assertIsNone(r['upstream_updated_utc'])
    def test_openligadb_bad_schema_hold(self):
        r=fetch_openligadb('2026-27',opener=lambda *a,**kw:Response(b'{}'))
        self.assertEqual(r['status'],'HOLD')
    def test_openligadb_duplicate_or_invalid_skipped(self):
        obj=json.loads(oldb_data());obj.append(obj[0]);obj.append({'matchID':23,'team1':{},'team2':{}})
        r=fetch_openligadb('2026-27',opener=lambda *a,**kw:Response(json.dumps(obj).encode()))
        self.assertEqual(len(r['matches']),2)
    def test_fallback_uses_openfootball(self):
        err=lambda *args,**kwargs:{'status':'HOLD','reason':'offline','matches':[]}
        good=lambda *args,**kwargs:{'status':'READY_RESEARCH','matches':[{'date':'2026-10-09','home':'A','away':'B'}], 'source':'OpenFootball'}
        r=get_fixtures('2026-27','bundesliga',clock=lambda:NOW,openligadb_fn=err,openfootball_fn=good)
        self.assertEqual(len(r['attempts']),2)
        self.assertEqual(r['source'],'OpenFootball')
        self.assertFalse(r['verified_live'])
    def test_both_sources_fail_closed(self):
        err=lambda *args,**kwargs:{'status':'HOLD','reason':'dns','matches':[]}
        r=get_fixtures('2026-27','bundesliga',clock=lambda:NOW,openligadb_fn=err,openfootball_fn=err)
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['reason'],'ALL_PUBLIC_SOURCES_FAILED')
    def test_window_avoids_season_start(self):
        a=[{'date':'2026-08-01','home':'Old','away':'B'},
           {'date':'2026-10-09','home':'Tomorrow','away':'D'},
           {'date':'2026-11-30','home':'Future','away':'F'}]
        self.assertEqual([x['home'] for x in select_window(a,now=NOW)],['Tomorrow'])
    def test_daily_collect_success_and_hold(self):
        def fake(*,season,league,clock):
            if league=='epl':return {'status':'READY_RESEARCH','source':'OpenFootball','captured_utc':NOW.isoformat(), 'matches':[{'date':'2026-10-09','home':'A','away':'B'},{'date':'2026-08-01','home':'Old','away':'B'}]}
            return {'status':'HOLD','reason':'network','matches':[]}
        r=collect_daily(('epl','laliga'),now=NOW,getter=fake)
        self.assertEqual(r['status'],'READY_RESEARCH')
        self.assertEqual(len(r['matches']),1)
        self.assertEqual(r['source_records'][1]['status'],'HOLD')
        self.assertEqual(r['dataset_total_matches'],2)
    def test_daily_publish_html_json_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            fixture={'status':'READY_RESEARCH','source':'OpenFootball','matches':[{'date':'2026-08-30','home':'Old','away':'X'},
              {'date':'2026-10-09','home':'<script>x</script>','away':'B','league':'epl'}],
              'source_records':[{'league':'epl','status':'READY_RESEARCH','source':'OpenFootball','window_matches':1}],
              'origin':'TEST_OFFLINE','verified_live':False}
            r,page=publish(site=Path(d)/'site',report_path=Path(d)/'data.json',now=NOW,fixture_override=fixture)
            html=page.read_text()
            self.assertIn('&lt;script&gt;',html)
            self.assertNotIn('<script>',html)
            self.assertNotIn('Old — X',html)
            self.assertIn('正式投注推薦：停用',html)
            self.assertEqual(json.loads((page.parent/'status.json').read_text())['window_matches'],1)
            self.assertEqual(r['production_recommendations'],'DISABLED')
    def test_daily_publish_empty_source_hold(self):
        with tempfile.TemporaryDirectory() as d:
            fixture={'status':'HOLD','matches':[],'origin':'TEST_OFFLINE','verified_live':False}
            r,p=publish(site=Path(d)/'site',report_path=Path(d)/'result.json',now=NOW,fixture_override=fixture)
            self.assertEqual(r['status'],'HOLD')
            self.assertIn('暫無可核實資料',p.read_text())
    def test_unrelated_bookmakers_not_comparable(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'odds.csv'
            with f.open('w',newline='') as h:
                w=csv.writer(h);w.writerow(['event_id','bookmaker','market','line','selection','decimal_odds','observed_utc','source_url'])
                w.writerow(['e1','b1','1x2','','home',2.1,NOW.isoformat(),'https://example.org'])
                w.writerow(['e2','b2','1x2','','home',2.2,NOW.isoformat(),'https://example.org'])
            r=run('2026-27',odds=f,offline=None,now=NOW,fixture_override={'status':'HOLD','matches':[]})
            self.assertEqual(r['checks']['B_odds']['status'],'HOLD')
            self.assertEqual(r['checks']['B_odds']['bookmakers'],2)
            self.assertEqual(r['checks']['B_odds']['comparable_groups'],0)
    def test_matching_bookmaker_group_research_only(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'odds.csv'
            with f.open('w',newline='') as h:
                w=csv.writer(h);w.writerow(['event_id','bookmaker','market','line','selection','decimal_odds','observed_utc','source_url'])
                for b in ['b1','b2']:w.writerow(['e1',b,'1x2','','home',2.1,NOW.isoformat(),'https://example.org'])
            r=run('2026-27',odds=f,now=NOW,fixture_override={'status':'HOLD','matches':[]})
            self.assertEqual(r['checks']['B_odds']['status'],'RESEARCH_ONLY')
            self.assertEqual(r['checks']['B_odds']['comparable_groups'],1)
            self.assertEqual(r['production_recommendations'],'DISABLED')

if __name__=='__main__':unittest.main()
