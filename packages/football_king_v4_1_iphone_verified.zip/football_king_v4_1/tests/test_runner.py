import unittest
from unittest.mock import patch
import io
from contextlib import redirect_stdout
import run
class RunnerTests(unittest.TestCase):
 def test_check(self):
  with redirect_stdout(io.StringIO()) as output: rc=run.main(['check'])
  self.assertEqual(rc,0)
  self.assertIn('production_recommendations',output.getvalue())
 def test_missing_key_is_hold(self):
  with patch.dict('os.environ',{},clear=True),redirect_stdout(io.StringIO()) as output:
   rc=run.main(['fixtures','--from-date','2026-10-08','--to-date','2026-10-08'])
  self.assertEqual(rc,2)
  self.assertIn('API_KEY_REQUIRED',output.getvalue())
