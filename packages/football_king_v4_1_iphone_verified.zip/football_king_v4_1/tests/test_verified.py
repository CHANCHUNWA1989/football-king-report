"""Regression tests for window validity and public report leakage."""
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from daily_publish import collect_daily, publish
from integrated import run
from mobile_site import build

NOW = datetime(2026, 10, 8, 10, 0, tzinfo=timezone.utc)


def source_with(rows):
    def getter(*, season, league, clock):
        return {'status': 'READY_RESEARCH', 'source': 'MockSource',
                'captured_utc': NOW.isoformat(), 'matches': rows}
    return getter


class VerifiedTests(unittest.TestCase):
    def test_all_old_games_hold_despite_http_success(self):
        matches = [{'date':'2026-08-01','home':'Old','away':'Team'}]
        r = collect_daily(('epl',), now=NOW, getter=source_with(matches))
        self.assertEqual(r['status'], 'HOLD')
        self.assertEqual(r['reason'], 'NO_MATCHES_IN_CURRENT_WINDOW')
        self.assertEqual(r['fetched_sources'], 1)
        self.assertEqual(r['usable_sources'], 0)
        self.assertEqual(r['source_records'][0]['fetch_status'], 'READY_RESEARCH')
        self.assertEqual(r['source_records'][0]['status'], 'HOLD')

    def test_current_games_research_only_and_not_certified(self):
        matches = [{'date':'2026-10-09','home':'Recent','away':'Team'}]
        r = collect_daily(('epl',), now=NOW, getter=source_with(matches))
        self.assertEqual(r['status'], 'READY_RESEARCH')
        self.assertEqual(r['usable_sources'], 1)
        self.assertEqual(r['production_recommendations'], 'DISABLED')

    def test_hold_override_with_rows_cannot_be_upgraded(self):
        r = run(now=NOW, fixture_override={
            'status':'HOLD','reason':'STALE','matches':[{'date':'2026-08-01','home':'A','away':'B'}]})
        self.assertEqual(r['status'], 'HOLD')
        self.assertEqual(r['checks']['A_fixtures']['status'], 'HOLD')

    def test_html_report_flags_stale_but_downloaded(self):
        with tempfile.TemporaryDirectory() as d:
            r, page = publish(site=Path(d)/'site', report_path=Path(d)/'report.json',
                              now=NOW, leagues=('epl',),
                              getter=source_with([{'date':'2026-08-01','home':'Old','away':'Team'}]))
            self.assertEqual(r['status'], 'HOLD')
            content = page.read_text(encoding='utf-8')
            self.assertIn('資料下載成功但近期賽事不足', content)
            self.assertNotIn('Old — Team', content)
            self.assertEqual(json.loads((page.parent/'status.json').read_text())['sources_http_success'], 1)

    def test_public_report_redacts_private_input(self):
        with tempfile.TemporaryDirectory() as d:
            private = 'SECRET_PRIVATE_ODDS_PAYLOAD_8675309'
            report = {'status':'RESEARCH_ONLY','checked_utc':NOW.isoformat(),
                      'checks':{'B_odds':{'status':'RESEARCH_ONLY','quotes':2}},
                      'fixtures':{'status':'READY_RESEARCH',
                                  'matches':[{'date':'2026-10-09','home':'A','away':'B',
                                              'private_note':private}]},
                      'odds':{'accepted':[{'bookmaker':'BookA','note':private}]},
                      'team_info':{'accepted':[{'name':'TeamA','note':private}]}}
            path = Path(d)/'private_report.json'
            path.write_text(json.dumps(report))
            site=build(path,Path(d)/'site')
            exposed = (site.parent/'report.json').read_text()
            self.assertNotIn(private,exposed)
            self.assertNotIn('accepted',exposed)
            self.assertIn('A',exposed)
            self.assertEqual(json.loads(exposed)['production_recommendations'],'DISABLED')

    def test_public_status_no_dangerous_recommendation(self):
        with tempfile.TemporaryDirectory() as d:
            report={'status':'HOLD','checked_utc':NOW.isoformat(),
                    'fixtures':{'matches':[]},'production_recommendations':'ENABLED'}
            path=Path(d)/'input.json';path.write_text(json.dumps(report))
            page=build(path,Path(d)/'site')
            published=json.loads((page.parent/'report.json').read_text())
            self.assertEqual(published['production_recommendations'],'DISABLED')
            self.assertEqual(json.loads((page.parent/'status.json').read_text())['production_recommendations'],'DISABLED')

if __name__=='__main__': unittest.main()
