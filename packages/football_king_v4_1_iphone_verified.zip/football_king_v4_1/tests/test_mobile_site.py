import unittest,tempfile,json
from pathlib import Path
from mobile_site import build
class MobileReportTests(unittest.TestCase):
    def test_hold_and_escape(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.json';p.write_text(json.dumps({'status':'HOLD','checked_utc':'2026-10-08T00:00:00Z','checks':{'A':{'status':'HOLD','reason':'offline'}},'fixtures':{'matches':[{'home':'<script>','away':'Team','date':'2026-10-08'}]}}))
            output=build(p,Path(d)/'site'); page=output.read_text()
            self.assertIn('正式投注推薦：停用',page)
            self.assertNotIn('<script>',page)
            self.assertIn('&lt;script&gt;',page)
            self.assertTrue((output.parent/'report.json').exists())
    def test_empty_fixture(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.json';p.write_text('{"status":"HOLD","checks":{},"fixtures":{}}')
            self.assertIn('暫無可核實資料',build(p,Path(d)/'site').read_text())
