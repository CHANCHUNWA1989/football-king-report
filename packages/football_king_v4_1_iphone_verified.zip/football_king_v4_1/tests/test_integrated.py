import unittest, tempfile, json, csv
from pathlib import Path
from datetime import datetime,timezone
from integrated import run
class IntegrationTests(unittest.TestCase):
    def test_missing_all_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'empty.json';p.write_text('{"matches":[],"status":"HOLD"}')
            r=run('2026-27',offline=p)
            self.assertEqual(r['status'],'HOLD')
            self.assertEqual(r['production_recommendations'],'DISABLED')
            self.assertEqual(r['checks']['B_odds']['status'],'HOLD')
    def test_offline_research_not_live(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixtures.json';p.write_text('{"matches":[{"date":"2026-10-09","home":"A","away":"B"}]}')
            r=run('2026-27',offline=p)
            self.assertEqual(r['status'],'RESEARCH_ONLY')
            self.assertFalse(r['fixtures']['verified_live'])
            self.assertEqual(r['checks']['C_deployment']['status'],'HOLD')
    def test_imported_two_books_not_certified(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);f=root/'f.json';f.write_text('{"matches":[]}')
            o=root/'odds.csv'; now=datetime.now(timezone.utc).isoformat()
            with o.open('w',newline='') as out:
                w=csv.writer(out);w.writerow(['event_id','bookmaker','market','line','selection','decimal_odds','observed_utc','source_url'])
                for b in ('BookA','BookB'):w.writerow(['match1',b,'1x2','','home','2.1',now,'https://example.org/odds'])
            r=run('2026-27',offline=f,odds=o)
            self.assertEqual(r['checks']['B_odds']['status'],'RESEARCH_ONLY')
            self.assertEqual(r['production_recommendations'],'DISABLED')
if __name__=='__main__':unittest.main()
