import unittest,sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hardening import check_quote
from pipeline import decide,ModelEvidence
from advanced import ensemble,devig
from engine import probabilities,evaluate_csv
from datetime import datetime,timezone
NOW='2026-10-08T12:00:00Z'
Q={'event_id':'E1','source':'demo','captured_utc':'2026-10-08T11:55:00Z','home':2.1,'draw':3.4,'away':3.8}
CASE={'case_id':'C1','event_id':'E1','kickoff_utc':'2026-10-08T13:00:00Z','lineup_confirmed':True,'market':'1X2','selection':'home'}
M=[{'home':.55,'draw':.25,'away':.2}]
E=ModelEvidence(True,True,'validated-demo',.5)
class Hardening(unittest.TestCase):
 def test_nan_odds(self):
  with self.assertRaises(ValueError): check_quote(dict(Q,home=float('nan')),datetime(2026,10,8,12,tzinfo=timezone.utc),'E1')
 def test_future_quote(self):
  with self.assertRaises(ValueError): check_quote(dict(Q,captured_utc='2026-10-08T12:01:00Z'),datetime(2026,10,8,12,tzinfo=timezone.utc),'E1')
 def test_ambiguous_quotes(self):
  r=decide(CASE,[Q,dict(Q,source='other')],M,[1],E,NOW)
  self.assertEqual(r['status'],'HOLD');self.assertIn('AMBIGUOUS_QUOTES_REQUIRE_EXPLICIT_SELECTION',r['issues'])
 def test_conservative_above_point(self):
  r=decide(CASE,[Q],M,[1],ModelEvidence(True,True,'validated-demo',.6),NOW)
  self.assertEqual(r['status'],'HOLD');self.assertIn('CONSERVATIVE_PROBABILITY_EXCEEDS_ESTIMATE',r['issues'])
 def test_unverified_id(self):
  r=decide(CASE,[Q],M,[1],ModelEvidence(True,True,'unverified',.5),NOW)
  self.assertIn('INVALID_MODEL_ID',r['issues'])
 def test_nan_prob(self):
  with self.assertRaises(ValueError): ensemble([{'home':float('nan'),'draw':.3,'away':.7}],[1])
 def test_nan_xg(self):
  with self.assertRaises(ValueError): probabilities(float('nan'),1.2)
 def test_nan_devig(self):
  with self.assertRaises(ValueError): devig({'home':float('nan'),'draw':3,'away':4})
if __name__=='__main__':unittest.main()
