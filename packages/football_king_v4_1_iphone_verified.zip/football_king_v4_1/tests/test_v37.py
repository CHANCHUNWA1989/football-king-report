import unittest,tempfile,csv,json
from pathlib import Path
from datetime import datetime,timedelta,timezone
from research_v37 import evaluate,transform
from sync_v37 import refresh
class V37(unittest.TestCase):
 def make(self,n=90):
  f=tempfile.NamedTemporaryFile(mode='w',suffix='.csv',delete=False,newline='');w=csv.writer(f);w.writerow(['case_id','prediction_utc','kickoff_utc','p_home','p_draw','p_away','outcome'])
  start=datetime(2025,1,1,tzinfo=timezone.utc)
  for i in range(n):
   t=start+timedelta(days=i);w.writerow([str(i),(t-timedelta(hours=12)).isoformat(),t.isoformat(),.5,.25,.25,['home','draw','away'][i%3]])
  f.close();return f.name
 def test_eval(self):
  r=evaluate(self.make());self.assertEqual(r['status'],'RESEARCH_ONLY');self.assertEqual(r['split'],[54,18,18])
 def test_small(self):self.assertEqual(evaluate(self.make(10))['status'],'HOLD')
 def test_bad_prob(self):
  p=self.make();t=Path(p).read_text();Path(p).write_text(t.replace('0.5,0.25,0.25','0.9,0.25,0.25',1));
  with self.assertRaises(ValueError):evaluate(p)
 def test_transform(self):self.assertAlmostEqual(sum(transform([.5,.25,.25],.8)),1.)
 def test_sync_ready(self):
  with tempfile.TemporaryDirectory() as td:
   today=datetime.now(timezone.utc).date().isoformat()
   r=refresh('2025-26','epl',str(Path(td)/'a.json'),0,lambda *_:{'status':'READY_RESEARCH','matches':[{'date':today,'home':'Home','away':'Away'}],'sha256':'abc'},lambda _:None)
   self.assertEqual(r['status'],'READY_RESEARCH');self.assertEqual(json.loads((Path(td)/'a.json').read_text())['report']['matches'],1)
 def test_sync_hold(self):
  with tempfile.TemporaryDirectory() as td:
   r=refresh('2025-26','epl',str(Path(td)/'a.json'),1,lambda *_:{'status':'HOLD','reason':'URLError','matches':[]},lambda _:None)
   self.assertEqual(r['status'],'HOLD')
 def test_sync_exception(self):
  with tempfile.TemporaryDirectory() as td:
   def fail(*a):raise RuntimeError('network')
   self.assertEqual(refresh('2025-26','epl',str(Path(td)/'a.json'),0,fail,lambda _:None)['reason'],'RuntimeError')
if __name__=='__main__':unittest.main()
