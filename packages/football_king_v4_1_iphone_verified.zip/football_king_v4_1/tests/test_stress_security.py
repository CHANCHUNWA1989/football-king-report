"""Reproducible adversarial regression tests for the iPhone report pipeline."""
import csv
import json
import random
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from daily_publish import collect_daily, publish
from fixture_gateway import get_fixtures
from fixture_safety import compact_matches, normalize_match
from integrated import run
from integrations_v38 import import_odds
from mobile_site import build

NOW=datetime(2026,10,8,10,0,tzinfo=timezone.utc)

def src(rows):
    def get(*,season,league,clock):
        return {'status':'READY_RESEARCH','source':'MOCK','matches':rows,'captured_utc':NOW.isoformat()}
    return get


class StressSecurityTests(unittest.TestCase):
    def test_mixed_kickoff_types_no_longer_crash(self):
        mixed=[{'date':'2026-10-09','home':'A','away':'B','kickoff_utc':42},
               {'date':'2026-10-09','home':'C','away':'D','kickoff_utc':'2026-10-09T12:00:00Z'},
               {'date':'2026-10-09','home':'E','away':'F'}]
        r=collect_daily(('epl',),now=NOW,getter=src(mixed))
        self.assertEqual(r['status'],'READY_RESEARCH')
        self.assertEqual(len(r['matches']),2)

    def test_normalize_excludes_wrong_timezone_day(self):
        self.assertIsNone(normalize_match({'date':'2026-10-09','home':'A','away':'B',
            'kickoff_utc':'2026-10-08T00:00:00Z'},NOW))

    def test_bad_field_lengths_rejected(self):
        self.assertIsNone(normalize_match({'date':'2026-10-09','home':'A'*10000,'away':'B'},NOW))
        self.assertIsNone(normalize_match({'date':'2026-10-09','home':'A','away':'a'},NOW))

    def test_massive_source_fails_closed(self):
        rows=[{'date':'2026-10-09','home':f'Team {i}','away':f'Team {i+1}'} for i in range(22000)]
        r=collect_daily(('epl',),now=NOW,getter=src(rows))
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['source_records'][0]['reason'],'SOURCE_EVENT_LIMIT_EXCEEDED')
        self.assertFalse(r['matches'])

    def test_large_fixture_collection_is_capped(self):
        rows=[{'date':'2026-10-09','home':f'Home {i}','away':f'Away {i}'} for i in range(4000)]
        r=collect_daily(('epl','laliga','bundesliga'),now=NOW,getter=src(rows))
        self.assertLessEqual(len(r['matches']),1200)
        self.assertTrue(r['events_truncated'])
        self.assertEqual(r['production_recommendations'],'DISABLED')

    def test_fuzzer_never_crashes_and_never_certifies(self):
        rng=random.Random(20261008)
        inputs=[None,{},'2026-10-09',{'date':42,'home':'A'},
                {'date':'2026-10-09','home':'A','away':'B','kickoff_utc':float('nan')}]
        for i in range(1000):
            inputs.append({'date':rng.choice([None,20261009,'2026-10-09','2026-10-12','2031-01-01']),
                           'home':rng.choice([None,42,f'A{i}','<script>']),
                           'away':rng.choice([None,42,f'B{i}','B']),
                           'kickoff_utc':rng.choice([None,42,'junk','2026-10-09T10:00:00Z'])})
        result=collect_daily(('epl',),now=NOW,getter=src(inputs))
        self.assertIn(result['status'],('READY_RESEARCH','HOLD'))
        self.assertEqual(result['production_recommendations'],'DISABLED')

    def test_stale_primary_falls_back_to_secondary(self):
        primary=lambda *args,**kw:{'status':'READY_RESEARCH','matches':[{'date':'2026-01-01','home':'A','away':'B'}]}
        secondary=lambda *args,**kw:{'status':'READY_RESEARCH','matches':[{'date':'2026-10-09','home':'C','away':'D'}]}
        result=get_fixtures('2026-27','bundesliga',clock=lambda:NOW,openligadb_fn=primary,openfootball_fn=secondary)
        self.assertEqual(result['status'],'READY_RESEARCH')
        self.assertEqual(len(result['attempts']),2)
        self.assertEqual(result['attempts'][0]['reason'],'NO_MATCHES_IN_CURRENT_WINDOW')

    def test_extreme_bad_source_does_not_block_other_league(self):
        def getter(*,season,league,clock):
            if league=='epl': raise RuntimeError('unexpected adapter failure')
            return src([{'date':'2026-10-09','home':'A','away':'B'}])(season=season,league=league,clock=clock)
        r=collect_daily(('epl','laliga'),now=NOW,getter=getter)
        self.assertEqual(r['status'],'READY_RESEARCH')
        self.assertEqual(r['source_records'][0]['reason'],'RuntimeError')
        self.assertEqual(r['source_records'][1]['status'],'READY_RESEARCH')

    def test_missing_csv_fails_closed_not_crash(self):
        r=run(now=NOW,odds='/missing/no.csv',team='/missing/no.csv',history='/missing/no.csv',
              fixture_override={'status':'HOLD','matches':[]})
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['checks']['B_odds']['status'],'HOLD')
        self.assertEqual(r['checks']['B_team_info']['status'],'HOLD')
        self.assertEqual(r['checks']['C_calibration']['status'],'HOLD')

    def test_oversized_odds_file_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'giant.csv'
            with path.open('wb') as f: f.truncate(10_000_001)
            with self.assertRaisesRegex(ValueError,'CSV_TOO_LARGE'):
                import_odds(path,NOW)

    def test_equivalent_line_notation_compares(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'odds.csv'
            with path.open('w',newline='') as f:
                w=csv.writer(f)
                w.writerow(['event_id','bookmaker','market','line','selection','decimal_odds','observed_utc','source_url'])
                w.writerow(['event1','Book A','over_under','2.50','over','1.9',NOW.isoformat(),'https://example.org'])
                w.writerow(['event1','Book B','over_under','2.5','over','1.91',NOW.isoformat(),'https://example.org'])
            r=run(now=NOW,odds=path,fixture_override={'status':'HOLD','matches':[]})
            self.assertEqual(r['checks']['B_odds']['comparable_groups'],1)

    def test_custom_source_urls_with_secrets_are_never_public(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r.json'
            token='supersecret-deployment-token'
            fakeurl='https://api.provider.example/data?token='+token
            p.write_text(json.dumps({'status':'RESEARCH_ONLY','checked_utc':NOW.isoformat(),
                'fixtures':{'source_url':fakeurl,'matches':[{'date':'2026-10-09','home':'A','away':'B',
                  'source_url':fakeurl}]},
                'fixture_source_records':[{'league':'epl','source_url':fakeurl}]}))
            build(p,Path(d)/'site')
            doc=(Path(d)/'site'/'report.json').read_text()
            self.assertNotIn(token,doc)
            self.assertNotIn(fakeurl,doc)

    def test_large_public_report_bounded_and_private_redacted(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'report.json'; site=Path(d)/'site'
            secret='PRIVATE_USER_TOKEN_abcdef'
            r={'checked_utc':NOW.isoformat(),'status':'RESEARCH_ONLY','production_recommendations':'ENABLED',
               'checks':{'B_odds':{'status':'HOLD'}},
               'odds':{'secrets':[secret]},
               'fixtures':{'matches':[{'date':'2026-10-09','home':f'H{i}','away':f'A{i}',
                            'internal_secret':secret} for i in range(3500)]}}
            path.write_text(json.dumps(r),encoding='utf-8')
            build(path,site)
            public=(site/'report.json').read_text()
            self.assertNotIn(secret,public)
            self.assertLessEqual(len(json.loads(public)['fixtures']['matches']),1200)
            self.assertEqual(json.loads((site/'status.json').read_text())['production_recommendations'],'DISABLED')
            self.assertTrue((site/'freshness.js').exists())

    def test_direct_stale_report_downgraded_to_hold(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'report.json';site=Path(d)/'site'
            p.write_text(json.dumps({'status':'RESEARCH_ONLY','checked_utc':NOW.isoformat(),
                'fixtures':{'matches':[{'date':'2025-10-09','home':'Old','away':'Team'}]}}))
            build(p,site)
            self.assertEqual(json.loads((site/'status.json').read_text())['status'],'HOLD')
            self.assertEqual(json.loads((site/'report.json').read_text())['status'],'HOLD')
            self.assertIn('HOLD', (site/'index.html').read_text())

    def test_report_html_escapes_script_payload(self):
        with tempfile.TemporaryDirectory() as d:
            r={'status':'RESEARCH_ONLY','checked_utc':NOW.isoformat(),
               'fixtures':{'matches':[{'date':'2026-10-09','home':'<script>alert(1)</script>','away':'B'}]}}
            p=Path(d)/'r.json';p.write_text(json.dumps(r))
            h=build(p,Path(d)/'site').read_text()
            self.assertNotIn('<script>alert(1)</script>',h)
            self.assertIn('&lt;script&gt;',h)

    def test_parallel_publish_results_are_parseable(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            fixture={'status':'READY_RESEARCH', 'matches':[{'date':'2026-10-09','home':'A','away':'B'}]}
            def worker(i):
                r,_=publish(site=base/'site',report_path=base/f'report{i}.json',now=NOW,fixture_override=fixture)
                return r['production_recommendations']
            with ThreadPoolExecutor(max_workers=8) as pool:
                self.assertEqual(list(pool.map(worker,range(32))),['DISABLED']*32)
            self.assertIn('足球王者',(base/'site'/'index.html').read_text())
            self.assertEqual(json.loads((base/'site'/'report.json').read_text())['production_recommendations'],'DISABLED')
            self.assertEqual(json.loads((base/'site'/'status.json').read_text())['production_recommendations'],'DISABLED')

    def test_oversized_direct_report_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'report.json'
            with p.open('wb') as f: f.truncate(16_000_001)
            with self.assertRaisesRegex(ValueError,'REPORT_JSON_TOO_LARGE'):
                build(p,Path(d)/'site')

if __name__=='__main__': unittest.main()
