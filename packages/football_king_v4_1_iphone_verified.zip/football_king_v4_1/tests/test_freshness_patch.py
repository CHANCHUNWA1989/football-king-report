"""New real failure-mode regressions, using injected clocks instead of network access."""
import json
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from unittest.mock import patch
from daily_publish import collect_daily
from fixture_gateway import get_fixtures
from fixture_safety import compact_matches, capture_age_error
from integrated import run
from mobile_site import build

NOW = datetime(2026, 10, 8, 15, 0, tzinfo=timezone.utc)
ROW={'date':'2026-10-09','home':'Alpha','away':'Beta','event_id':'source:99'}


def getter_with_capture(captured, rows=None):
    def getter(*,season,league,clock):
        return {'status':'READY_RESEARCH','source':'MockPublic','captured_utc':captured,
                'matches':list(rows if rows is not None else [ROW])}
    return getter


class FreshnessPatchTests(unittest.TestCase):
    def test_captured_old_is_rejected_daily(self):
        r=collect_daily(('epl',),now=NOW,getter=getter_with_capture((NOW-timedelta(hours=50)).isoformat()))
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['source_records'][0]['reason'],'STALE_SOURCE_CAPTURE')
        self.assertEqual(len(r['matches']),0)

    def test_future_capture_rejected(self):
        r=collect_daily(('epl',),now=NOW,getter=getter_with_capture((NOW+timedelta(hours=1)).isoformat()))
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['source_records'][0]['reason'],'SOURCE_CAPTURE_IN_FUTURE')

    def test_invalid_capture_rejected(self):
        r=collect_daily(('epl',),now=NOW,getter=getter_with_capture('yesterday'))
        self.assertEqual(r['source_records'][0]['reason'],'INVALID_SOURCE_CAPTURE_TIME')

    def test_capture_boundary_valid(self):
        self.assertIsNone(capture_age_error((NOW-timedelta(hours=36)).isoformat(),NOW))
        self.assertIsNone(capture_age_error(NOW.isoformat(),NOW))

    def test_conflicting_event_id_quarantined(self):
        second={**ROW,'away':'Gamma'}
        result,reason=compact_matches([ROW,second],now=NOW)
        self.assertEqual(result,[])
        self.assertEqual(reason,'CONFLICTING_EVENT_IDENTITIES')

    def test_conflicts_hold_even_with_other_valid_match(self):
        additional={**ROW,'event_id':'source:100','home':'Third','away':'Fourth'}
        r=collect_daily(('epl',),now=NOW,getter=getter_with_capture(NOW.isoformat(),[ROW,{**ROW,'away':'Gamma'},additional]))
        self.assertEqual(r['status'],'HOLD')
        self.assertEqual(r['source_records'][0]['reason'],'CONFLICTING_EVENT_IDENTITIES')
        self.assertEqual(r['matches'],[])

    def test_gateway_stale_primary_uses_backup(self):
        bad=lambda *a,**kw: {'status':'READY_RESEARCH','matches':[ROW], 'captured_utc':(NOW-timedelta(days=3)).isoformat()}
        good=lambda *a,**kw: {'status':'READY_RESEARCH','matches':[ROW], 'captured_utc':NOW.isoformat()}
        result=get_fixtures('2026-27','bundesliga',clock=lambda:NOW,openligadb_fn=bad,openfootball_fn=good)
        self.assertEqual(len(result['attempts']),2)
        self.assertEqual(result['attempts'][0]['reason'],'STALE_SOURCE_CAPTURE')
        self.assertEqual(result['status'],'READY_RESEARCH')

    def test_integrated_stale_never_research(self):
        result=run(now=NOW,fixture_override={'status':'READY_RESEARCH','matches':[ROW], 'captured_utc':(NOW-timedelta(days=2)).isoformat()})
        self.assertEqual(result['status'],'HOLD')
        self.assertEqual(result['checks']['A_fixtures']['status'],'HOLD')

    def test_static_site_stale_report_is_hold_without_js(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'report.json'
            file.write_text(json.dumps({'status':'RESEARCH_ONLY','checked_utc':(NOW-timedelta(days=4)).isoformat(),
                'fixtures':{'matches':[ROW]}}))
            output=build(file,Path(d)/'site',wall_clock=NOW)
            self.assertIn('報告產生時間過期',output.read_text())
            self.assertEqual(json.loads((output.parent/'status.json').read_text())['status'],'HOLD')

    def test_site_rejects_future_report(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'report.json'
            file.write_text(json.dumps({'status':'RESEARCH_ONLY','checked_utc':(NOW+timedelta(hours=3)).isoformat(),
                'fixtures':{'matches':[ROW]}}))
            output=build(file,Path(d)/'site',wall_clock=NOW)
            self.assertEqual(json.loads((output.parent/'report.json').read_text())['status'],'HOLD')

    def test_current_report_stays_research(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'report.json'
            file.write_text(json.dumps({'status':'RESEARCH_ONLY','checked_utc':NOW.isoformat(),
                'fixtures':{'matches':[ROW]}}))
            output=build(file,Path(d)/'site',wall_clock=NOW)
            self.assertEqual(json.loads((output.parent/'status.json').read_text())['status'],'RESEARCH_ONLY')

if __name__=='__main__':unittest.main()

class SeasonAndWorkflowTests(unittest.TestCase):
    def test_keyless_sync_optional_season(self):
        import subprocess,sys
        r=subprocess.run([sys.executable,'sync_v37.py','--help'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0)
        self.assertIn('--season SEASON',r.stdout)
        self.assertNotIn('--season SEASON\n                        ',r.stdout)

    def test_keyless_workflows_do_not_pin_season(self):
        root=Path(__file__).resolve().parents[1]
        for wf in ('keyless-sync.yml','integrated-research.yml'):
            s=(root/'.github'/'workflows'/wf).read_text()
            self.assertNotIn('--season 2026-27',s)

class KeylessSyncSafetyTests(unittest.TestCase):
    def test_sync_does_not_claim_ready_for_invalid_rows(self):
        from sync_v37 import refresh
        with tempfile.TemporaryDirectory() as d:
            report=refresh('2026-27','epl',str(Path(d)/'latest.json'),0,
                           fetcher=lambda *_:{'status':'READY_RESEARCH','matches':[{}]},sleeper=lambda _:None)
            self.assertEqual(report['status'],'HOLD')
            self.assertEqual(report['reason'],'NO_MATCHES_IN_CURRENT_WINDOW')

    def test_sync_rejects_old_snapshot(self):
        from sync_v37 import refresh
        today=datetime.now(timezone.utc).date().isoformat()
        with tempfile.TemporaryDirectory() as d:
            report=refresh('2026-27','epl',str(Path(d)/'latest.json'),0,
                fetcher=lambda *_:{'status':'READY_RESEARCH','matches':[{'date':today,'home':'A','away':'B'}],
                  'captured_utc':(datetime.now(timezone.utc)-timedelta(days=3)).isoformat()},sleeper=lambda _:None)
            self.assertEqual(report['status'],'HOLD')
            self.assertEqual(report['reason'],'STALE_SOURCE_CAPTURE')
