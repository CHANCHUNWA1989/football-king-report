# 足球王者 V3.3：安全及結算修復版

獨立複製 V3.2；未修改任何 V2.8 / V3.1 / V3.2 來源檔案。

## 已完成
- `settlement.py`：亞洲讓球 (AH) 與大小球 (OU) 的整數、半球、四分一球盤；支援半贏、半輸及走盤。
- `validation.py`：CSV 1X2 歷史預測檢查、時間先後核查、重複 Case ID 檢查、Log Loss、Brier、校準分箱及資料 SHA256。
- `pipeline.py`：拒絕自行聲稱校準完成的輸入標記；在沒有獨立、可信模型驗證證據的情況下始終 HOLD。
- `tests/test_new.py`：新增 8 個回歸測試。

## 指令
```bash
python -m unittest discover -s tests -v
python validation.py predictions.csv --minimum 100
python monitor.py sample_pipeline.json --now 2026-10-08T12:00:00Z --log audit.jsonl
```

`predictions.csv` 必須包含：`case_id,prediction_utc,kickoff_utc,p_home,p_draw,p_away,outcome`，按照 kickoff_utc 遞增。

## 未完成，不能聲稱已接通
- 真實多供應商即時賠率、正選、傷停、xG 數據及授權。
- 可持續運行的雲端監控及主動通知。
- 真實歷史資料訓練、樣本外模型比較及可信模型簽核。
- V2.8 原始檔案的完整遷移。
- 完整亞洲盤回測引擎、CLV、交易成本與市場流動性。

**系統維持研究模式；正式推薦一律 HOLD。**
