"""Football King local entrypoint: diagnostics, authorized fixtures, or offline tests."""
import argparse, json, os, subprocess, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from collector import collect
from openfootball import fetch as fetch_openfootball

def main(argv=None):
    p=argparse.ArgumentParser(description='Football King V3.5 runner')
    p.add_argument('command',choices=['check','fixtures','test','openfootball'])
    p.add_argument('--from-date'); p.add_argument('--to-date'); p.add_argument('--out'); p.add_argument('--season'); p.add_argument('--league',default='epl')
    a=p.parse_args(argv)
    if a.command=='test':
        return subprocess.call([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=Path(__file__).parent)
    if a.command=='check':
        result={'version':'3.6','status':'READY_LOCAL','python':sys.version.split()[0],
                'utc':datetime.now(timezone.utc).isoformat(),
                'openfootball_keyless':'AVAILABLE_NOT_LIVE_VERIFIED','fixtures_api':'CONFIGURED' if os.getenv('FOOTBALL_DATA_API_KEY') else 'API_KEY_REQUIRED',
                'odds_api':'NOT_CONFIGURED','xg_lineup_api':'NOT_CONFIGURED',
                'calibration':'NOT_VALIDATED','production_recommendations':'DISABLED'}
    elif a.command=='openfootball':
        today=datetime.now(timezone.utc).date()
        season=a.season or (f'{today.year}-{(today.year+1)%100:02d}' if today.month>=7 else f'{today.year-1}-{today.year%100:02d}')
        result=fetch_openfootball(season,a.league)
    else:
        today=datetime.now(timezone.utc).date()
        start=a.from_date or today.isoformat(); end=a.to_date or (today+timedelta(days=1)).isoformat()
        result=collect(start,end)
    payload=json.dumps(result,ensure_ascii=False,indent=2)
    if a.out: Path(a.out).write_text(payload,encoding='utf-8')
    print(payload)
    return 0 if result['status'] in ('READY','READY_LOCAL','READY_RESEARCH') else 2

if __name__=='__main__': raise SystemExit(main())
